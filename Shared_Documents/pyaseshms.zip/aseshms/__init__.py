# A toolkit for ASES HMS team

__all__ = ['PKGINFO']
__version__ = 0.01

from aseshms import util as au

# Initialize to get PKGINFO
PKGINFO = au.PkgEnvInfo()


# Let users know if they're missing any of our hard dependencies
hard_dependencies = ("tkinter", "pandas", "xlsxwriter", "tqdm",
                     "pkg_resources", "openpyxl", "shutil")
missing_dependencies = []

for dependency in hard_dependencies:
    try:
        __import__(dependency)
    except ImportError as e:
        missing_dependencies.append(dependency)

if missing_dependencies:
    raise ImportError(
        "Missing required dependencies {0}".format(missing_dependencies))
del hard_dependencies, dependency, missing_dependencies
