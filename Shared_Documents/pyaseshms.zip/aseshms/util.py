#! C:/Docs/Continuum/Anaconda3/python.exe
# -*- coding: utf-8 -*-

"""
主题: 应用工具类
日期: 2017/12/06
python: 3.6.3_64bit
"""

__all__ = ['PkgEnvInfo', 'GuiApp', 'GuiRadioChecker']

# -----------------------Import packages----------------------------------
import os
import platform
import tkinter as tk
from tkinter import Radiobutton, Button, Frame

from aseshms import generic as ag

# ---------------------------Initial Env Info----------------------------------


class PkgEnvInfo:

    def __init__(self):
        self.cwdir = os.getcwd()
        self.arch, self.system = platform.architecture()[:2]
        self.machine = platform.machine()
        self.python_version = platform.python_version()
        try:
            self.aetna_build = len(os.environ['AETNA_BUILD_INFO']) > 0
        except Exception:
            self.aetna_build = False
        self.username = os.environ['USERNAME']
        # get machine arch: 32 or 64
        pc_arch = self.arch[:2]
        # Search xpdf
        try:
            self.xpdfdir = os.environ['xpdfdir']
        except Exception:
            if self.system[:3] == "Win":
                self.xpdfdir = ag.get_folder(title=u'选择xpdfbin根目录',
                                             initialdir="C:/")
            else:
                self.xpdfdir = ag.get_folder(title=u'选择xpdfbin根目录',
                                             initialdir="/")
        self.dir_sep = '/'
        if self.system[:3] == "Win":
            self.dir_sep = "\\"

        if not os.path.exists(self.xpdfdir):
            self.xpdfdir = ""
        if not os.path.exists(self.xpdfdir + self.dir_sep + 'bin' + pc_arch):
            self.xpdfdir = ""

        if self.xpdfdir == "":
            self.pdftotext = self.pdfinfo = self.pdftohtml = self.pdftopng =   \
                self.pdftoppm = self.pdftops = self.pdfimages =   \
                self.pdffonts = self.pdfdetach = ""
        else:
            xpdfbindir = self.xpdfdir + self.dir_sep + 'bin' + pc_arch
            self.pdftotext = ag.find_file("pdftotext*", xpdfbindir)
            self.pdfinfo = ag.find_file("pdfinfo*", xpdfbindir)
            self.pdftohtml = ag.find_file("pdftohtml*", xpdfbindir)
            self.pdftopng = ag.find_file("pdftopng*", xpdfbindir)
            self.pdftoppm = ag.find_file("pdftoppm*", xpdfbindir)
            self.pdftops = ag.find_file("pdftops*", xpdfbindir)
            self.pdfimages = ag.find_file("pdfimages*", xpdfbindir)
            self.pdffonts = ag.find_file("pdffonts*", xpdfbindir)
            self.pdfdetach = ag.find_file("pdfdetach*", xpdfbindir)

    def __repr__(self):
        info_dict = self.show()
        out = ''
        max_key_len = max([len(x) for x in info_dict.keys()])
        for k, v in info_dict.items():
            out = out + ('\t' * (round(max_key_len/8)-int(len(str(k))/8)) +
                         ':\t').join((str(k), str(v))) + '\n'
        return out

    def show(self, attributes=None):
        attr_dict = {'arch': self.arch, 'system': self.system,
                     'machine': self.machine,
                     'python_version': self.python_version,
                     'aetna_build': self.aetna_build,
                     'username': self.username, 'dir_sep': self.dir_sep,
                     'cwdir': self.cwdir, 'xpdfdir': self.xpdfdir,
                     'pdftotext': self.pdftotext, 'pdfinfo': self.pdfinfo,
                     'pdftohtml': self.pdftohtml, 'pdftopng': self.pdftopng,
                     'pdftoppm': self.pdftoppm, 'pdftops': self.pdftops,
                     'pdfimages': self.pdfimages, 'pdffonts': self.pdffonts,
                     'pdfdetach': self.pdfdetach}
        if attributes is None:
            return attr_dict
        else:
            if isinstance(attributes, (tuple, list)):
                return {k: attr_dict.get(k) for k in attributes}
            else:
                return attr_dict.get(attributes)

    def reset(self):
        self.__init__()

    def updateCwdir(self, to_value):
        self.cwdir = to_value

# ---------------------Gui object App on top of Tk----------------------------


class GuiApp(tk.Frame):
    """General class of tk Gui"""
    def __init__(self, master=None):
        super().__init__(master)
        self.pack()


class GuiRadioChecker(GuiApp):
    """
    Tk GUI Radiobutton Checker

    Argument:
    - master tk window
    - initial value for the radiobuttons
    - value list for radiobuttons
    """
    def __init__(self, master, init_val, val_list):
        self.val = None
        self.init_val = init_val
        if not isinstance(val_list, (tuple, list)):
            val_list = [(val_list, val_list), ]
        self.val_list = val_list
        if all(isinstance(self.val_list[i][1], int) for i in
                range(len(self.val_list))):
            try:
                self.init_val = int(self.init_val)
            except Exception:
                self.init_val = None
        else:
            self.init_val = str(self.init_val)
        self.master = master
        self.master.geometry('{}x{}'.format(300, (len(val_list)+1)*25+50))
        self.createRadios()
        self.createButtons()

    def createRadios(self):
        self.frame1 = Frame(self.master, width=400,
                            height=len(self.val_list)*25+80)
        self.frame1.pack()
        if isinstance(self.init_val, int):
            self.radioVar = tk.IntVar(self.master)
        else:
            self.radioVar = tk.StringVar(self.master)

        self.radioVar.set(self.init_val)
        for lbl, val in self.val_list:
            Radiobutton(self.frame1, text=lbl, variable=self.radioVar,
                        value=val).pack(anchor=tk.N)

    def clickOk(self):
        self.val = self.radioVar.get()
        self.master.quit()

    def clickCancel(self):
        self.val = None
        self.master.quit()

    def createButtons(self):
        self.ok_button = Button(self.master, text=u"确定 OK",
                                command=self.clickOk)
        self.cancel_button = Button(self.master, text=u"取消 Cancel",
                                    command=self.clickCancel)
        self.ok_button.pack(anchor=tk.S)
        self.cancel_button.pack(anchor=tk.S)
        self.ok_button.place(x=10, y=len(self.val_list)*25+10, height=30,
                             width=120)
        self.cancel_button.place(x=150, y=len(self.val_list)*25+10, height=30,
                                 width=120)

    def __repr__(self):
        if self.val is None:
            val = ''
        else:
            val = self.val
        return str(val)

    def show(self):
        return self.val
