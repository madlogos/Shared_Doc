# -*- coding: utf-8 -*-

"""
主题: 应用工具类
日期: 2017/12/06
python: 3.6.3_64bit
"""

__all__ = ['PkgEnvInfo', 'GuiApp', 'GuiRadioChecker', 'logging_assert',
           'YamlValidator', 'PdfParserYamlValidator']

# -----------------------Import packages----------------------------------
import logging
import os
import pkg_resources
import platform
import re
import tkinter as tk
import warnings

from tkinter import Radiobutton, Button, Frame
from aseshms import generic as ag


# ---------------------------Initial Env Info----------------------------------
class PkgEnvInfo(dict):
    """
    载入aseshms包后，读取相关环境工具信息。

    Attributes:
        None
    """
    def __init__(self):
        super().__init__()
        self.setInitValues()

    def setInitValues(self):
        self['cwdir'] = os.getcwd()
        self['arch'], self['system'] = platform.architecture()[:2]
        self['machine'] = platform.machine()
        self['python_version'] = platform.python_version()
        try:
            self['aetna_build'] = len(os.environ['AETNA_BUILD_INFO']) > 0
        except Exception:
            self['aetna_build'] = False
        self['username'] = os.environ['USERNAME']
        # get machine arch: 32 or 64
        pc_arch = self.arch[:2]
        # Search xpdf
        try:
            self['xpdfdir'] = os.environ['xpdfdir']
        except Exception:
            if self['system'][:3] == "Win":
                self['xpdfdir'] = ag.get_folder(title=u'选择xpdfbin根目录',
                                                initialdir="C:/")
            else:
                self['xpdfdir'] = ag.get_folder(title=u'选择xpdfbin根目录',
                                                initialdir="/")
        self['dir_sep'] = '/'
        if self['system'][:3] == "Win":
            self['dir_sep'] = "\\"

        if not os.path.exists(self['xpdfdir']):
            self['xpdfdir'] = ""
        if not os.path.exists(''.join([self['xpdfdir'], self['dir_sep'], 'bin',
                                       pc_arch])):
            self['xpdfdir'] = ""

        if self['xpdfdir'] == "":
            self['pdftotext'] = self['pdfinfo'] = self['pdftohtml'] = \
                self['pdftopng'] = self['pdftoppm'] = self['pdftops'] = \
                self['pdfimages'] = self['pdffonts'] = self['pdfdetach'] = ""
        else:
            xpdfbindir = ''.join([self['xpdfdir'], self['dir_sep'], 'bin',
                                  pc_arch])
            self['pdftotext'] = ag.find_file("pdftotext*", xpdfbindir)
            self['pdfinfo'] = ag.find_file("pdfinfo*", xpdfbindir)
            self['pdftohtml'] = ag.find_file("pdftohtml*", xpdfbindir)
            self['pdftopng'] = ag.find_file("pdftopng*", xpdfbindir)
            self['pdftoppm'] = ag.find_file("pdftoppm*", xpdfbindir)
            self['pdftops'] = ag.find_file("pdftops*", xpdfbindir)
            self['pdfimages'] = ag.find_file("pdfimages*", xpdfbindir)
            self['pdffonts'] = ag.find_file("pdffonts*", xpdfbindir)
            self['pdfdetach'] = ag.find_file("pdfdetach*", xpdfbindir)

    def __repr__(self):
        info_dict = self.show()
        out = ''
        max_key_len = max([len(x) for x in info_dict.keys()])
        for k, v in info_dict.items():
            out = out + ('\t' * (round(max_key_len/8)-int(len(str(k))/8)) +
                         ':\t').join((str(k), str(v))) + '\n'
        return out

    def __getattr__(self, key):
        """dict形式显示环境工具取值，如要美观打印，用__repr___

        Args:
            key: 属性key
        """
        try:
            if isinstance(key, (tuple, list)):
                return {k: self.get(k) for k in key}
            elif isinstance(key, str):
                return self.get(key)
        except KeyError:
            raise AttributeError(
                r"'PkgInfo' object does not have attribute %s" % key)

    def __setattr__(self, key, value):
        """修改某个属性"""
        self[key] = value

    def show(self, attributes=None):
        """dict形式显示环境工具取值，如要美观打印，用__repr___
        Args:
            attributes: 属性或属性列表。如None，则全取
        """
        if attributes is None:
            return {k: self.get(k) for k in self.keys()}
        else:
            if isinstance(attributes, (tuple, list)):
                return {k: self.get(k) for k in attributes}
            elif isinstance(attributes, str):
                return self[attributes]

    def reset(self):
        """再次__init__()，重置环境工具信息
        """
        self.clear()
        self.__init__()

    def updateCwdir(self, value):
        """设置Cwdir以便复用
        """
        self.__setattr__('cwdir', value)


# ---------------------Gui object App on top of Tk----------------------------
class GuiApp(tk.Frame):
    """General class of tk Gui inherited from tk.Frame
    """
    def __init__(self):
        super().__init__()
        self.pack()


class GuiRadioChecker(GuiApp):
    """
    Tk GUI Radiobutton Checker, subclass of GuiApp

    Attributes:
        master: tk root window
        init_val: initial value for the radiobuttons
        val_list: value list for radiobuttons
        val: returning value
        tk widgets:
            frame1: tk frame
            radioVar: radio button values
            ok_button: ok button
            cancel_button: cancel button
    """
    def __init__(self, master, init_val, val_list):
        """__init__ mothod of GuiRadioChecker

        Attributes:
            master: tk root window
            init_val: initial value for the radiobuttons
            val_list: value list for radiobuttons
        """
        super().__init__()
        self.val = None
        self.init_val = init_val
        if not isinstance(val_list, (tuple, list)):
            val_list = [(val_list, val_list), ]
        self.val_list = val_list
        if all(isinstance(self.val_list[i][1], int) for i in
                range(len(self.val_list))):
            try:
                self.init_val = int(self.init_val)
            except Exception:
                self.init_val = None
        else:
            self.init_val = str(self.init_val)
        self.master = master
        self.master.geometry('{}x{}'.format(300, (len(val_list)+1)*25+50))
        self.createRadios()
        self.createButtons()

    def createRadios(self):
        """Create buttons for the frame"""
        self.frame1 = Frame(self.master, width=400,
                            height=len(self.val_list)*25+80)
        self.frame1.pack()
        if isinstance(self.init_val, int):
            self.radioVar = tk.IntVar(self.master)
        else:
            self.radioVar = tk.StringVar(self.master)

        self.radioVar.set(self.init_val)
        for lbl, val in self.val_list:
            Radiobutton(self.frame1, text=lbl, variable=self.radioVar,
                        value=val).pack(anchor=tk.N)

    def clickOk(self):
        """Action clicking OK button"""
        self.val = self.radioVar.get()
        self.master.quit()

    def clickCancel(self):
        """Action clicking Cancel button"""
        self.val = None
        self.master.quit()

    def createButtons(self):
        """Action creating OK and Cancel buttons"""
        self.ok_button = Button(self.master, text=u"确定 OK",
                                command=self.clickOk)
        self.cancel_button = Button(self.master, text=u"取消 Cancel",
                                    command=self.clickCancel)
        self.ok_button.pack(anchor=tk.S)
        self.cancel_button.pack(anchor=tk.S)
        self.ok_button.place(x=10, y=len(self.val_list)*25+10, height=30,
                             width=120)
        self.cancel_button.place(x=150, y=len(self.val_list)*25+10, height=30,
                                 width=120)

    def __repr__(self):
        if self.val is None:
            val = ''
        else:
            val = self.val
        return str(val)

    def show(self):
        return self.val


# -------------------------validate templates--------------------------------
def logging_assert(cond, exc, ignore_errors=True):
    """
    Assert a condition using logging module

    Args:
        cond (statement): Condition to assert, e.g, 1 == 0
        exc (str): Exception info to output. e.g, 'Error found'
        ignore_errors (bool): If False, pause the program.

    Returns:
        If an AssertionError is caught, return '', else None
    """
    try:
        assert cond
    except AssertionError:
        logging.exception(exc)
        if not ignore_errors:
            raise Exception('Exiting due to assertion errors...')
        return ''


class YamlValidator(object):
    """
    Template validator wrapper. The template should be .yml file

    Attributes:
        file: The path of the .yml template
        tpls: The list loaded from the yml template file.
    """
    def __init__(self, file=None):
        """__init__ mothod of YamlValidator

        Args:
            file: The path of the .yml template
        """
        self.file = file
        self.tpls = ag.load_yaml(file=file)

    def __repr__(self):
        return str(self.tpls)

    def validateInit(self):
        """Export a log entry for start.
        """
        logging.basicConfig(level=logging.DEBUG,
                            format='%(asctime)s - %(levelname)s - %(message)s')
        logging.info(''.join(['Starting to validate template ',
                              os.path.realpath(self.file), ' ...']))

    def validatePass(self):
        """Export a log entry to exclaim validation success.
        """
        logging.info('Template validation passed.')

    def validateFail(self):
        """Export a log entry to exclaim validation failure.
        """
        logging.warning('Template validation failed. Check the log/traceback.')


class PdfParserYamlValidator(YamlValidator):
    """
    Wrapper of PdfParser's template validator. It is a subclass of
    YamlValidator.

    Attributes:
        file (str): Path of the template, default the internal template in
            pdfparse module.
        ignore_errors (bool): Whether ignore assertion errors and move on.
            Default True.
        validation (bool): Whether the template passes validation.
    """
    def __init__(self,
                 file=pkg_resources.resource_filename(
                    'aseshms', 'pdfparse/template.yml'),
                 ignore_errors=True):
        """__init__ method of PdfParserYamlValidator

        Args:
            file (str): Path of the template, default the internal template in
                pdfparse module.
            ignore_errors (bool): Whether ignore assertion errors and move on.
                Default True.
        """
        YamlValidator.__init__(self, file=file)
        self.ignore_errors = ignore_errors
        self.validation = False

    def validate(self):
        """Validate the YAML template's structure
        """
        def _assertLogging(cond, exc):
            out = logging_assert(cond, exc, ignore_errors=self.ignore_errors)
            if out is not None:
                YamlValidator.validateFail(self)
        # init the validation
        YamlValidator.validateInit(self)
        # check every element
        tpls = self.tpls
        _assertLogging(
            isinstance(tpls, list), '_0_ Template YAML must be a list.')
        tplnames = list()
        for i in range(len(tpls)):
            # L1 review
            _assertLogging(isinstance(tpls[i], dict), ''.join(
                ["_1_ #", str(i+1), " template is not a python dict."]))
            list_shouldbe = ['name', 'provider', 'rule', 'meta', 'repl',
                             'sect']
            _assertLogging(
                set(list(tpls[i].keys())) == set(list_shouldbe), ''.join(
                    ["_1_ #", str(i+1), " template with bad structure. ",
                     "Level 1 dict keys should be ", str(list_shouldbe), "."]))
            try:
                tplnames.append(tpls[i]['name'])
            except Exception:
                tplnames.append('#' + str(i+1))
        count_names = dict((i, tplnames.count(i)) for i in tplnames)
        _assertLogging(
            all([i == 1 for i in count_names.values()]), ' '.join(
                ["_1_ Duplicated names have been used in the template: ",
                 str(count_names)]))

        for i in range(len(tpls)):  # loop into the lists
            # Name
            _assertLogging(
                isinstance(tpls[i]['name'], str), ''.join(
                    ["_2_ [Name] of #", str(i+1),
                     " template has bad structure. Should be character."]))
            # provider
            _assertLogging(
                isinstance(tpls[i]['provider'], str) or
                tpls[i]['provider'] is None, ''.join(
                    ["_2_ [Provider] of #", str(i+1), " template has bad ",
                     "structure. Should be character or None."]))
            tplname = tplnames[i]
            # rules
            _assertLogging(
                isinstance(tpls[i]['rule'], list), ''.join(
                    ["_2_ [Rule] of #", str(i+1), " template (", tplname,
                     ") has bad structure. Should be a list."]))
            for j in range(len(tpls[i]['rule'])):
                line = tpls[i]['rule'][j]
                _assertLogging(
                    isinstance(line, str), ''.join(
                        ['_3_ #', str(j+1), ' [rule] in #', str(i+1),
                         ' template (', tplname, ') has bad structure. ',
                         'Should be character.']))
            # meta
            _assertLogging(
                isinstance(tpls[i]['meta'], dict), ''.join(
                    ["_2_ [Meta] of #", str(i+1),
                     " template is not a python dict."]))
            list_shouldbe = ['Name', 'Gender', 'Age', 'CertNum', 'EENum',
                             'RecId', 'Yr', 'Mo', 'Dt', 'Tel']
            _assertLogging(
                set(list(tpls[i]['meta'].keys())) == set(list_shouldbe),
                ''.join(["_2_ [Meta] of #", str(i+1), " template (", tplname,
                         ") has bad structure. Keys should be ",
                         str(list_shouldbe), "."]))
            for j in range(len(tpls[i]['meta'].values())):
                line = list(tpls[i]['meta'].values())[j]
                _assertLogging(
                    (isinstance(line, list) and isinstance(line[0], str)
                     and isinstance(line[1], int)) or line is None,
                    ''.join(['_3_ The #', str(j+1), ' [meta] in #', str(i+1),
                             ' template (', tplname, ') has bad structure. ',
                             'Should be a list ([str, int]).']))
            # repl
            _assertLogging(
                isinstance(tpls[i]['repl'], list) or tpls[i]['repl'] is None,
                ''.join(
                    ['_2_ [Repl] of #', str(i+1), ' template (', tplname,
                     ') should be a list or None.']))
            for j in range(len(tpls[i]['repl'])):
                line = tpls[i]['repl'][j]
                _assertLogging(
                    (isinstance(line, list) and isinstance(line[0], str)
                     and isinstance(line[1], str)) or line is None,
                    ''.join(['_3_ #', str(j+1), ' [repl] in #', str(i+1),
                             ' template (', tplname, ') has bad structure.',
                             ' Should be a list ([str, str, <str>]).']))
                if len(line) > 2:
                    _assertLogging(
                        (all([v.upper() in list('AILMSUX') for v in line[2]])),
                        ''.join(['_3_ #', str(j+1), ' [repl] in #', str(i+1),
                                 ' template (', tplname, ') has bad',
                                 ' structure. The third element must be a',
                                 ' valid re.flag synonym ("A|I|L|M|S|U|X")']))
                if re.search('@=|=@', line[1]) and \
                        not re.search('@=[vx]=@', line[1]):
                    warnings.warn(''.join(['The 2nd part of #', str(j+1),
                                           ' [repl] in #', str(i+1),
                                           ' template (', tplname,
                                           ') might be incorrect. Either ',
                                           '@=v=@ or @=x=@ required.']))
            # sect
            _assertLogging(
                isinstance(tpls[i]['sect'], dict), ''.join(
                    ['_2_ [Sect] of #', str(i+1), ' template (', tplname, ') ',
                     'is not a python dict.']))
            for j in range(len(tpls[i]['sect'])):
                sect_name = list(tpls[i]['sect'].keys())[j]
                line = tpls[i]['sect'][sect_name]
                _assertLogging(
                    isinstance(line, dict), ''.join(
                        ["_3_ [Sect] #", str(j+1), " of #", str(i+1),
                         " template (", tplname, ") is not a python dict."]))
                list_shouldbe = ['header', 'category', 'repl',
                                 'combine_above', 'combine_keep_breaks',
                                 'col_blanks', 'transpose', 'validate']
                _assertLogging(
                    set(list(line.keys())) == set(list_shouldbe), ''.join(
                        ["_3_ [Sect] #", str(j+1), "of #", str(i+1),
                         " template (", tplname, ") with bad structure. ",
                         "The keys should be ", str(list_shouldbe), "."]))
                # header
                _assertLogging(
                    isinstance(line['header'], dict) and
                    set(line['header'].keys()) == {'pattern', 'group',
                                                   'label', 'default'} and
                    isinstance(line['header']['pattern'], list) and
                    isinstance(line['header']['group'], list) and
                    (isinstance(line['header']['label'], list) or
                     line['header']['label'] is None) and
                    (isinstance(line['header']['default'], list) or
                     line['header']['default'] is None), ''.join(
                        ["_4_ [Header] of [sect] #", str(j+1), " of #",
                         str(i+1), " template (", tplname,
                         ") has bad structure. Should be a dict ",
                         "{pattern: list, group: list, label: list or None,",
                         "default: list or None}."]))
                _assertLogging(all([isinstance(x, str) for x in
                                   line['header']['pattern']]), ''.join(
                    ['_5_ [Header] [pattern] of sect #', str(j+1), ' of #',
                     str(i+1), ' template (', tplname, ') should be all ',
                     'str.']))
                if len(line['header']['pattern']) > 1:
                    _assertLogging(
                        (all([v.upper() in list('AILMSUX') for v in
                             list(line['header']['pattern'][1])])),
                        ''.join(['_5_ The 2nd element in [Header] [pattern] ',
                                 'of sect #', str(j+1), ' of #', str(i+1),
                                 ' template (', tplname, ') should be a ',
                                 ' valid re.flag synonym ("A|I|L|M|S|U|X")']))
                _assertLogging(all([isinstance(x, (str, int)) for x in
                                    line['header']['group']]), ''.join(
                    ["_5_ [Header] [group] of [sect] #", str(j+1), "of #",
                     str(i+1), " template (", tplname, ") should be all ",
                     "str or int."]))
                if line['header']['label'] is not None:
                    _assertLogging(all([isinstance(x, str) for x in
                                        line['header']['label']]), ''.join(
                        ["_5_ [Header] [label] of [sect] #", str(j+1), "of #",
                         str(i+1), " template (", tplname, ") should be all ",
                         "str."]))
                    _assertLogging(
                        len(line['header']['group']) == len(
                            line['header']['label']),
                        ''.join(["_5_ [Header] of [sect] #", str(j+1), "of #",
                                 str(i+1), " template (", tplname,
                                 ") with bad structure. 'group' and 'label' ",
                                 "should be lists of the same length."]))
                if line['header']['default'] is not None:
                    _assertLogging(all([isinstance(x, str) for x in
                                        line['header']['default']]), ''.join(
                        ["_5_ [Header] [default] of [sect] #", str(j+1),
                         "of #", str(i+1), " template (", tplname,
                         ") should be all str."]))
                    _assertLogging(
                        len(line['header']['group']) == len(
                            line['header']['default']),
                        ''.join(["_5_ [Header] of [sect] #", str(j+1), "of #",
                                 str(i+1), " template (", tplname,
                                 ") with bad structure. 'group' and 'default'",
                                 " should be lists of the same length."]))
                # category
                _assertLogging(
                    isinstance(line['category'], list) and
                    isinstance(line['category'][0], str) and
                    isinstance(line['category'][1], int), ''.join(
                        ["_4_ [Category] of [sect] #", str(j+1), "in #",
                         str(i+1), " template (", tplname, ") with ",
                         "bad structure. Should be a list (str, int)."]))
                # ... category[0] must contain '()' for re.search.groups()
                _assertLogging(
                    re.search('\(', line['category'][0]) and
                    re.search('\)', line['category'][0]), ''.join(
                        ["_5_ 1st element of [Category] in[sect] #", str(j+1),
                         "of #", str(i+1), " template (", tplname, ") with ",
                         "invalid regex. Should contains '()' for grouping."]))
                # repl
                _assertLogging(
                    isinstance(line['repl'], list) or line['repl'] is None,
                    ''.join(['_4_ [Repl] of [sect] #', str(j+1), "in #",
                            str(i+1), ' template (', tplname, ') should be a ',
                            'list or None.']))
                if line['repl'] is not None:
                    for k in range(len(line['repl'])):
                        replrule = line['repl'][k]
                        _assertLogging(
                            (isinstance(replrule, list) and
                             isinstance(replrule[0], str) and
                             isinstance(replrule[1], str)) or line is None,
                            ''.join(['_5_ #', str(k+1), ' [repl] in #',
                                     str(j+1), ' [sect] in #', str(i+1),
                                     ' template (', tplname, ') has bad',
                                     ' structure. Should be a list ',
                                     '([str, str, <str>]).']))
                        if len(replrule) > 2:
                            _assertLogging(
                                (all([v.upper() in list('AILMSUX') for v in
                                     replrule[2]])), ''.join(
                                     ['_6_ The 3rd element in #', str(k+1),
                                      ' [repl] in #', str(j+1), ' [sect] in #',
                                      str(i+1), ' template (', tplname,
                                      ') should be a valid re.flag synonym ',
                                      '("A|I|L|M|S|U|X")']))
                # combine
                _assertLogging(
                    (isinstance(line['combine_above'], list) and
                     all([isinstance(x, str) for x in line['combine_above']]))
                    or line['combine_above'] is None, ''.join(
                        ["_4_ [Combine_above] of sect #", str(j+1), "of #",
                         str(i+1), " template (", tplname, ") with bad ",
                         "structure. Should be a character list or None."]))
                _assertLogging(
                    (isinstance(line['combine_keep_breaks'], list) and
                     all([isinstance(x, str) for x in
                          line['combine_keep_breaks']]))
                    or line['combine_keep_breaks'] is None, ''.join(
                        ["_4_ [combine_keep_breaks] of [sect] #", str(j+1),
                         "of #", str(i+1), " template (", tplname,
                         ") with bad ", "structure. Should be a character",
                         "list or None."]))
                # col_blanks
                _assertLogging(
                    line['col_blanks'] is None or
                    re.search('^ *\d* *, *\d* *$', line['col_blanks']),
                    ''.join(["_4_ [Col_blanks] of [sect] #", str(j+1), "of #",
                             str(i+1), " template (", tplname, ") with bad ",
                             "structure. Should be a character ('int,int') ",
                             "or None."]))
                # transpose
                _assertLogging(
                    (isinstance(line['transpose'], list) and
                     all([isinstance(x, str) for x in line['transpose']]))
                    or line['transpose'] is None, ''.join(
                        ["_4_ [Transpose] of [sect] #", str(j+1), "of #",
                         str(i+1), " template (", tplname,
                         ") with bad structure. ",
                         "Should be a charac ter list or None."]))
                if line['transpose'] is not None:
                    _assertLogging(
                        len(line['transpose']) == len(line['header']['group']),
                        ''.join(["_4_ [Transpose] of [sect] #", str(j+1),
                                 "of #", str(i+1), " template (", tplname,
                                 ") should be of the same length as ",
                                 "`group` & `label` of header."]))
                # validate
                _assertLogging(
                    (isinstance(line['validate'], list) and
                     all([isinstance(x, str) for x in line['validate']]))
                    or line['validate'] is None, ''.join(
                        ["_4_ [Validate] of [sect] #", str(j+1), "of #",
                         str(i+1), " template (", tplname,
                         ") with bad structure. ",
                         "Should be a character list or None."]))
                if line['validate'] is not None:
                    _assertLogging(
                        len(line['validate']) == len(line['header']['group']),
                        ''.join(["_4_ [Validate] of [sect] #", str(j+1),
                                 "of #", str(i+1), " template (", tplname,
                                 ") should be of the same length as " +
                                 "`group` & `label` in header."]))
        self.validation = True
        YamlValidator.validatePass(self)
