#! C:/Docs/Continuum/Anaconda3/python.exe
# -*- coding: utf-8 -*-

"""
主题: 一般工具函数
日期: 2017/12/06
python: 3.6.3_64bit
"""

__all__ = ['get_files', 'get_file', 'get_folder', 'find_file', 'find_files',
           'find_folder', 'find_folders', 'get_files_dir', 'get_pdfs',
           'get_txts', 'get_xlsx', 'get_xls']

# -----------------------Import packages----------------------------------
import tkinter as tk
from tkinter import filedialog as filedlg
from tkinter import messagebox as msgbox
import fnmatch
import os
import re
import traceback

import aseshms
# --------------------Functions for pointing files------------------


def get_files(filetypes=[("PDF files", "*.pdf")],
              title=u"选择pdf文件(可按住Shift多选)", extension=".pdf",
              initialdir="~", multi=True):
    """
    GUI向导指定多个文件, 默认找pdf
    返回{'dir': dir, 'files': (files)}
    如files=''，则返回{'dir': None, 'files': None}
    """
    root = tk.Tk()
    root.withdraw()
    try:
        # pdfs=[f for f in os.listdir(filepath) if f.lower().endswith(".pdf")]
        files = filedlg.askopenfilenames(
            title=title, parent=root, defaultextension=extension,
            filetypes=filetypes, initialdir=initialdir, multiple=multi)
        dir = get_files_dir(files)
        aseshms.PKGINFO.updateCwdir(dir)
        if files == '':
            dir = files = None
        return {'dir': dir, 'files': files}
    except SystemExit:
        pass
    except Exception:
        traceback.print_exc()
        msgbox.showerror(title=u"找不到指定类型的文件",
                         message=u"找不到指定类型的文件")
        return {}
    root.destroy()


def get_file(filetypes=[("PDF files", "*.pdf")],
             title=u"选择pdf文件(可按住Shift多选)", extension=".pdf",
             initialdir="~"):
    """
    GUI向导指定单个文件, 默认找pdf
    返回{'dir': dir, 'files': (files)}
    """
    return get_files(filetypes, title, extension, initialdir, multi=False)


def get_pdfs(initialdir=None, multi=True):
    if initialdir is None:
        initialdir = aseshms.PKGINFO.cwdir
    out = get_files(filetypes=[("PDF files", "*.pdf")],
                    title=u"选择pdf文件(可按住Shift多选)", extension=".pdf",
                    initialdir=initialdir, multi=multi)
    return(out)


def get_txts(initialdir=None, multi=True):
    if initialdir is None:
        initialdir = aseshms.PKGINFO.cwdir
    out = get_files(filetypes=[("TXT files", "*.txt")],
                    title=u"选择txt文件(可按住Shift多选)", extension=".txt",
                    initialdir=initialdir, multi=multi)
    return(out)


def get_xls(initialdir=None, multi=True):
    if initialdir is None:
        initialdir = aseshms.PKGINFO.cwdir
    out = get_files(filetypes=[("XLS files", "*.xls")],
                    title=u"选择xls文件(可按住Shift多选)", extension=".xls",
                    initialdir=initialdir, multi=multi)
    return(out)


def get_xlsx(initialdir=None, multi=True):
    if initialdir is None:
        initialdir = aseshms.PKGINFO.cwdir
    out = get_files(filetypes=[("XLSX files", "*.xlsx")],
                    title=u"选择xlsx文件(可按住Shift多选)", extension=".xlsx",
                    initialdir=initialdir, multi=multi)
    return(out)


def get_yaml(initialdir=None, multi=True):
    if initialdir is None:
        initialdir = aseshms.PKGINFO.cwdir
    out = get_files(filetypes=[("YAML files", "*.yml;*.yaml")],
                    title=u"选择YML文件(可按住Shift多选)", extension=".yml",
                    initialdir=initialdir, multi=multi)
    return(out)
# --------------------Functions for pointing dir------------------


def get_folder(title=u"选择文件夹", initialdir="~"):
    """
    GUI向导指定文件夹
    返回文件夹名称
    """
    root_tk = tk.Tk()
    root_tk.withdraw()
    try:
        folder = filedlg.askdirectory(title=title, parent=root_tk,
                                      mustexist=1, initialdir=initialdir)
        aseshms.PKGINFO.update_cwdir(folder)
        return folder
    except SystemExit:
        pass
    except Exception:
        traceback.print_exc()
        msgbox.showerror(title=u"未指定路径", message=u"未指定文件夹路径")
        return ''
    root_tk.destroy()

# --------------------Functions for pointing dir------------------


def find_files(pattern, path):
    """
    工具函数，遍历查找所有符合 pattern的文件
    pattern 必须是fnmatch类型，如'*.txt'
    """
    result = []
    for root, dirs, files in os.walk(path):
        for name in files:
            if fnmatch.fnmatch(name, pattern):
                result.append(os.path.join(root, name))
    return result


def find_file(pattern, path, i=0):
    """
    遍历查找第i个符合pattern的文件
    pattern 必须是fnmatch类型，如'*.txt'
    """
    try:
        return find_files(pattern, path)[i]
    except SystemExit:
        pass
    except Exception:
        traceback.print_exc()
        return []


def find_folders(pattern, path):
    """
    工具函数，遍历查找所有符合pattern的目录
    返回[folders]
    """
    result = []
    for root, dirs, files in os.walk(path):
        for name in dirs:
            if fnmatch.fnmatch(name, pattern):
                result.append(os.path.join(root, name))
    return result


def find_folder(pattern, path, i=0):
    """
    遍历查找第i个符合pattern的文件夹
    返回folders[i]
    """
    try:
        return find_folders(pattern, path)[i]
    except SystemExit:
        pass
    except Exception:
        traceback.print_exc()
        return []


def get_files_dir(files):
    """
    从文件中提取其文件夹，如果不来自同一个文件夹，则返回''
    """
    root_tk = tk.Tk()
    root_tk.withdraw()
    if not isinstance(files, (tuple, list)):
        files = [files, ]

    try:
        dir = re.sub(r'^(.+?)[^\\/\.]+\.[^\.]*$', r'\1', files[0])
        check_dir = [re.search(dir, file) is not None for file in files]
        if not all(check_dir):
            msgbox.showwarning(u"文件不来自同一个目录", u"文件不是来自同一个目录")
            root_tk.destroy()
            return ''
        return dir

    except SystemExit:
        pass
    except Exception:
        traceback.print_exc()

    root_tk.destroy()
