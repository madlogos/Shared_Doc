# -*- coding: utf-8 -*-

"""
主题: 一般工具函数
日期: 2017/12/06
python: 3.6.3_64bit
"""

__all__ = ['get_files', 'get_file', 'get_folder', 'find_file', 'find_files',
           'find_folder', 'find_folders', 'get_files_dir', 'get_pdfs',
           'get_txts', 'get_xlsx', 'get_xls', 'get_yaml', 'load_yaml',
           'regex_flag2int', 'validate_yaml', 'reflow_list', 'search_partial']

# -----------------------Import packages----------------------------------
import tkinter as tk
from tkinter import filedialog as filedlg
from tkinter import messagebox as msgbox
from yaml.constructor import ConstructorError
import fnmatch
import numpy as np
import os
# import pdb
import re
import traceback
import warnings
import yaml

import aseshms
from aseshms import util as au


# --------------------Functions for pointing files------------------
def _openfiles(title, parent, defaultextension,  filetypes, initialdir,
               multiple):
    """Identical to filedlg.askopenfilenames, simply for unittest"""
    return filedlg.askopenfilenames(
        title=title, parent=parent, defaultextension=defaultextension,
        filetypes=filetypes, initialdir=initialdir, multiple=multiple)


def _errmsg(title, message):
    """Identical to msgbox.showerror, simply for unittest"""
    msgbox.showerror(title=title, message=message)


def _warnmsg(title, message):
    """Identical to msgbox.showwarmomg, simply for unittest"""
    msgbox.showwarning(title=title, message=message)


def get_files(filetypes=[("PDF files", "*.pdf")],
              title=u"选择pdf文件(可按住Shift多选)", extension=".pdf",
              initialdir="~", multi=True):
    """GUI向导指定多个文件, 默认找pdf

    Args:
        filetypes (list): 默认[("PDF files", "*.pdf")]
        title (str): GUI窗口标题
        extension (str): 要找的文件后缀名，默认".pdf"
        initialdir (str): 初始路径，默认Cwdir"~"
        multi (bool): 是否可多选，默认True

    Returns:
        Dict {'dir': dir, 'files': (files)}
        如files=''，则返回{'dir': None, 'files': None}
    """
    root = tk.Tk()
    root.withdraw()
    try:
        # pdfs=[f for f in os.listdir(filepath) if f.lower().endswith(".pdf")]
        files = _openfiles(
            title=title, parent=root, defaultextension=extension,
            filetypes=filetypes, initialdir=initialdir, multiple=multi)
        dir = get_files_dir(files)
        aseshms.PKGINFO['cwdir'] = dir
        if files == '':
            dir = files = None
        return {'dir': dir, 'files': files}
    except SystemExit:
        pass
    except Exception:
        traceback.print_exc()
        _errmsg(title=u"找不到指定类型的文件", message=u"找不到指定类型的文件")
        return {}
    root.destroy()


def get_file(filetypes=[("PDF files", "*.pdf")],
             title=u"选择pdf文件(可按住Shift多选)", extension=".pdf",
             initialdir="~"):
    """GUI向导指定单个文件, 默认找pdf

    Args:
        filetypes (list): 默认[("PDF files", "*.pdf")]
        title (str): GUI窗口标题
        extension (str): 要找的文件后缀名，默认".pdf"
        initialdir (bool): 初始路径，默认Cwdir"~"

    Returns:
        Dict {'dir': dir, 'files': (files)}
    """
    return get_files(filetypes, title, extension, initialdir, multi=False)


def get_pdfs(initialdir=None, multi=True):
    """GUI向导指定pdf，get_files的快捷函数之一

    Args:
        initialdir (str): 初始路径，默认None，即aseshms.PKGINFO['cwdir']
        multi (bool): 是否可多选，默认True

    Returns:
        Dict {'dir': dir, 'files': (files)}
    """
    if initialdir is None:
        initialdir = aseshms.PKGINFO['cwdir']
    out = get_files(filetypes=[("PDF files", "*.pdf")],
                    title=u"选择pdf文件(可按住Shift多选)", extension=".pdf",
                    initialdir=initialdir, multi=multi)
    return(out)


def get_txts(initialdir=None, multi=True):
    """GUI向导指定txt，get_files的快捷函数之一

    Args:
        initialdir (str): 初始路径，默认None，即aseshms.PKGINFO['cwdir']
        multi (bool): 是否可多选，默认True

    Returns:
        Dict {'dir': dir, 'files': (files)}
    """
    if initialdir is None:
        initialdir = aseshms.PKGINFO['cwdir']
    out = get_files(filetypes=[("TXT files", "*.txt")],
                    title=u"选择txt文件(可按住Shift多选)", extension=".txt",
                    initialdir=initialdir, multi=multi)
    return(out)


def get_xls(initialdir=None, multi=True):
    """GUI向导指定xls(不可找xlsx)，get_files的快捷函数之一

    Args:
        initialdir (str): 初始路径，默认None，即aseshms.PKGINFO['cwdir']
        multi (bool): 是否可多选，默认True

    Returns:
        Dict {'dir': dir, 'files': (files)}
    """
    if initialdir is None:
        initialdir = aseshms.PKGINFO['cwdir']
    out = get_files(filetypes=[("XLS files", "*.xls")],
                    title=u"选择xls文件(可按住Shift多选)", extension=".xls",
                    initialdir=initialdir, multi=multi)
    return(out)


def get_xlsx(initialdir=None, multi=True):
    """GUI向导指定xlsx(不可找xls)，get_files的快捷函数之一

    Args:
        initialdir (str): 初始路径，默认None，即aseshms.PKGINFO['cwdir']
        multi (bool): 是否可多选，默认True

    Returns:
        Dict {'dir': dir, 'files': (files)}
    """
    if initialdir is None:
        initialdir = aseshms.PKGINFO['cwdir']
    out = get_files(filetypes=[("XLSX files", "*.xlsx")],
                    title=u"选择xlsx文件(可按住Shift多选)", extension=".xlsx",
                    initialdir=initialdir, multi=multi)
    return(out)


def get_yaml(initialdir=None, multi=True):
    """GUI向导指定yaml/yml，get_files的快捷函数之一

    Args:
        initialdir (str): 初始路径，默认None，即aseshms.PKGINFO['cwdir']
        multi (bool): 是否可多选，默认True

    Returns:
        Dict {'dir': dir, 'files': (files)}
    """
    if initialdir is None:
        initialdir = aseshms.PKGINFO['cwdir']
    out = get_files(filetypes=[("YAML files", "*.yml;*.yaml")],
                    title=u"选择YML文件(可按住Shift多选)", extension=".yml",
                    initialdir=initialdir, multi=multi)
    return(out)


# --------------------Functions for pointing dir------------------
def _opendir(title, parent, mustexist, initialdir):
    """Identical to filedlg.askdirectory, simply for unittest"""
    return filedlg.askdirectory(title=title, parent=parent,
                                mustexist=mustexist, initialdir=initialdir)


def get_folder(title=u"选择文件夹", initialdir="~"):
    """GUI向导指定文件夹

    Args:
        title (str): GUI窗口标题
        initialdir (str): 初始路径，默认Cwdir "~"

    Returns:
        str 文件夹名称
    """
    root_tk = tk.Tk()
    root_tk.withdraw()
    try:
        folder = _opendir(title=title, parent=root_tk,
                          mustexist=1, initialdir=initialdir)
        aseshms.PKGINFO['cwdir'] = folder
        return folder
    except SystemExit:
        pass
    except Exception:
        _errmsg(title=u"未指定路径", message=u"未指定文件夹路径")
        traceback.print_exc()
        return ''
    root_tk.destroy()


# --------------------Functions for pointing dir------------------
def find_files(pattern, path):
    """工具函数，递归遍历查找所有符合 pattern的文件

    Args:
        pattern (str): 文件名模式，必须是fnmatch模块支持的类型，如'*.txt'
        path (str): 要找的路径

    Returns:
        列表 [files]
    """
    result = []
    for root, dirs, files in os.walk(path):
        for name in files:
            if fnmatch.fnmatch(name, pattern):
                result.append(os.path.join(root, name))
    return result


def find_file(pattern, path, i=0):
    """递归遍历查找第i个符合pattern的文件，find_files的衍生函数

    Args:
        pattern (str): 文件名模式，必须是fnmatch模块支持的类型，如'*.txt'
        path (str): 要找的路径
        i (int): 返回的文件名序号

    Returns:
        列表 [files]
    """
    try:
        return find_files(pattern, path)[i]
    except SystemExit:
        pass
    except Exception:
        traceback.print_exc()
        return []


def find_folders(pattern, path):
    """工具函数，遍历查找所有符合pattern的目录

    Args:
        pattern (str): 路径名模式，必须是fnmatch模块支持的类型，如'*.txt'
        path (str): 要找的路径

    Returns:
        列表 [folders]
    """
    result = []
    for root, dirs, files in os.walk(path):
        for name in dirs:
            if fnmatch.fnmatch(name, pattern):
                result.append(os.path.join(root, name))
    return result


def find_folder(pattern, path, i=0):
    """遍历查找第i个符合pattern的文件夹，find_folders的衍生函数

    Args:
        pattern (str): 路径名模式，必须是fnmatch模块支持的类型，如'*.txt'
        path (str): 文本，要找的路径
        i (int): 路径名序号

    Returns:
        folders[i]
    """
    try:
        return find_folders(pattern, path)[i]
    except SystemExit:
        pass
    except Exception:
        traceback.print_exc()
        return []


def get_files_dir(files, gui=True):
    """从同一级文件中提取其文件夹

    Args:
        files (list): 文件名列表
        gui (bool): 是否调用GUI窗口报错

    Returns:
        str 路径名。如果files不来自同一个文件夹，则返回''。
    """
    root_tk = tk.Tk()
    root_tk.withdraw()

    try:
        if len(files) > 0:
            if not isinstance(files, (tuple, list)):
                files = [files, ]
            dir = os.path.dirname(os.path.commonprefix(files))
            if dir == '':
                files_show = str(files)[:100]
                if gui:
                    _warnmsg(u"文件不来自同一目录", u"文件%s不是来自同一个目录" %
                             files_show)
                else:
                    warnings.warn(u"文件%s不来自同一个目录" % files_show)
                root_tk.destroy()
        else:
            dir = ''
        return dir

    except SystemExit:
        pass
    except Exception:
        traceback.print_exc()
        raise

    root_tk.destroy()


# -----------------load config files (YAML)------------------
def _no_duplicates_constructor(loader, node, deep=False):
    """[Internal] Check for duplicate keys when importing yaml.
    """
    mapping = {}
    for key_node, value_node in node.value:
        key = loader.construct_object(key_node, deep=deep)
        value = loader.construct_object(value_node, deep=deep)
        if key in mapping:
            raise ConstructorError(
                "While constructing a mapping", node.start_mark,
                "found duplicate key (%s)" % key, key_node.start_mark)
        mapping[key] = value

    return loader.construct_mapping(node, deep)


def load_yaml(stream=None, file=None):
    """Load a yaml file or stream to generate a list/dict
    The Constructor is modified, so if there are duplicate keys in yaml,
    a ConstructorError will be triggered.

    Args:
        stream (stream): either a yaml text or a file stream
            (e.g., _io.TextIOWrapper), default None
        file (str): the full path of the yaml file, default None
            (pre-installed yml template)

    Returns:
        Parsed yaml object, list or dict
    """
    try:
        yaml.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG,
                             _no_duplicates_constructor)
        if stream is None:
            if file is None:
                file = get_yaml()
            else:
                if not os.path.isfile(file) or not  \
                     file.lower().endswith(('.yml', '.yaml')):
                        raise ValueError('No valid YAML files found!')
                        return None
            with open(file, 'r', encoding="UTF-8") as f:
                out = yaml.load(f)
        else:
            with stream:
                out = yaml.load(stream)
        return out
    except Exception:
        raise
        return None


# -----------------------Other functions---------------------
def convCharFull2Half(ustring):
    """把字符串全角转半角
    """
    rstring = ""
    for uchar in ustring:
        inside_code = ord(uchar)
        if inside_code == 12288:  # 全角空格直接转换
            inside_code = 32
        elif (inside_code >= 65281 and inside_code <= 65374):
            # 全角字符（除空格）根据关系转化
            inside_code -= 65248

        rstring += chr(inside_code)
    return rstring


def reflow_list(lst, header, validate):
    """Reflow the list based on TxtParser template's `validate` field.
    It is designed to facilitate TxtSectionParser.makeTable()

    Args:
        lst (list): the string list generated from TxtSectionParser.splitBody()
        header (dict): the 'header' part of the template['sect'] for TxtParser,
            structure {"pattern": list, "group": list, "label": list/None,
                       "default": list/None}, `group`, `label` and `default`
                       must be of the same length if is not None
        validate (list): the 'validate' part of the template['sect'] for
            TxtParser

    Returns:
        A new list reflowed based on `validate`
    """
    # Argument validation
    assert isinstance(header, dict)
    assert set(header.keys()) == {'pattern', 'group', 'label', 'default'}
    assert isinstance(validate, list) or validate is None
    # index of str elem in header['group']
    idx_str = [i for i in range(len(header['group']))
               if isinstance(header['group'][i], str)]
    # retain positions according to idx_int from `group`
    len_lst = len(lst)
    # lst = [lst[x] for x in header['group'] if
    #        isinstance(x, int) and x < len_lst]
    # insert elem at the corresponding position if there is default value
    for i in idx_str:
        if header['default'] is not None:
            if header['default'][i] is not None and header['default'][i] != '':
                lst.insert(i, header['default'][i])

    # -----------Matrix Solution: Adjust and reflow based on validate-------
    def judge_mtx():
        # build deterministic matrix for str matching
        # rows: element of lst; cols: validate
        # 2: match; 1: '' in validate; 0: '' in lst; -1: not match
        mtx = np.matrix(
            [[0 if x == '' else 1 if y == '' else 2 if re.search(y, x) else -1
              for y in validate] for x in lst])
        return mtx

    if validate is not None:
        mtx = judge_mtx()
        # remove elements that do not match any pattern in validate
        for i in range(mtx.shape[0]):
            if mtx[i].max() < 0:
                del lst[i]
        if len(lst) < len_lst:
            mtx = judge_mtx()

        vec = [''] * mtx.shape[1]  # init a vector as long as group
        lo = 0
        for i in range(mtx.shape[0]):
            if lo > len(vec):
                vec.extend([''] * (lo - len(vec)))
            if lo < len(vec):
                lo = mtx[i, lo:].argmax() + lo
                if lo < len(vec):
                    if mtx[i, lo:].max() > 0:
                        vec[lo] = lst[i]
                        lo += 1
    else:
        vec = lst.copy()
    # -----------Traditional Solution: Adjust and reflow based on validate----
    # # lock a position in lst, the loop will begin the scan from lock_pos
    # scan_init_pt = 0
    # vec = lst.copy()
    # if validate is not None:
    #     # re match loc by loc
    #     for i in range(len(validate)):
    #         if validate[i] is None or validate[i] == '':
    #             continue
    #         else:
    #             # insert '' if validate[i] not matching vec[i]
    #             if i < len(vec) and vec[i] is not None and vec[i] != '':
    #                 # pdb.set_trace()
    #                 if not re.search(validate[i], vec[i]):
    #                     vec[i:i] = ['']
    #         j = scan_init_pt
    #         while j < len(vec):
    #             if vec[j] is None or vec[j] == '':
    #                 j += 1
    #                 continue
    #             if re.search(validate[i], vec[j]):
    #                 if i > j:
    #                     vec[j:j] = [''] * (i - j)
    #                     j = i
    #                 elif i < j:
    #                     to_del = []
    #                     for k in range(i, j):
    #                         if vec[k] is None or vec[k] == '':
    #                             to_del.append(k)
    #                     vec = [vec[x] for x in range(len(vec))
    #                            if x not in to_del]
    #                     j -= len(to_del)
    #             scan_init_pt = j = j + 1
    # if too short, extend the tail
    if len(vec) < len(header['label']):
        vec.extend([''] * (len(header['label']) - len(vec)))
    # if too long, trim the tail
    while len(vec) > len(header['label']) and vec[-1] in (None, ''):
        del vec[-1]
    if (len(vec) != len(header['label'])):
        warnings.warn('lst "%r" not as long as header_label "%r".' %
                      (vec, header['label']))
    # pdb.set_trace()
    return vec


def validate_yaml(file=None, template='pdfparser'):
    """Validate yaml template's structure. Wrapper of util.YamlParser.

    Args:
        file (str): file path of the yaml template. default None.
        template (str): type of the template. default 'pdfparser'.

    Returns:
        (Bool) pass or not.
    """
    VALID_TPL = ['pdfparser', ]
    template = template.lower()
    if template.lower() not in VALID_TPL:
        raise ValueError('template must be of values %s' % VALID_TPL)
    if template == 'pdfparser':
        if file is None:
            yml = au.PdfParserYamlValidator()
        else:
            yml = au.PdfParserYamlValidator(file)
        yml.validate()
    return yml.validation


def regex_flag2int(flag):
    """Turn synonym of re.flags to int.

    Args:
        flag (str): Any combination of
            'A': re.A / ASCII
            'I': re.I / IGNORECASE
            'L': re.L / LOCALE
            'M': re.M / MULTILINE
            'S': re.S / DOTALL
            'U': re.U / UNICODE
            'X': re.X / VERBOSE

    Returns:
        Regex flag (int). E.g. flag = 'AM' -> re.A + re.M = 264
    """
    if isinstance(flag, str):
        if not all([v.upper() in list('AILMSUX') for v in list(flag)]):
            raise ValueError('flag must be of value in %r' % list('AILMSUX'))
        dictFlag = {'A': re.A, 'I': re.I, 'L': re.L, 'M': re.M, 'S': re.S,
                    'U': re.U, 'X': re.X}
        flagVal = [dictFlag[k.upper()] for k in set(flag)]
        return sum(flagVal)
    else:
        return None


def search_partial(token, string, percent=0.5):
    """Match partial string of `token` in `string` using `re.search`.

    Args:
        token (str): a string
        string (str): a string
        percent (float or int): 0-1

    Returns:
        Bool.

    Example:
        search_partial('abc', 'abd', 0.5) = True, since 0.5 of the token's
            length is 1.5 (approx. 2), either of its running segments ('ab' or
            'bc') matches 'abd' would meet the standard.
        When percent == 1, it is equal to `re.search`.
    """
    assert isinstance(token, str)
    assert isinstance(string, str)
    assert isinstance(percent, (float, int)) and percent >= 0 and percent <= 1
    std = percent * len(token)
    if std > int(std):
        std = int(std) + 1
    else:
        std = int(std)
    tokens = [token[i:(i + std)] for i in range(len(token) - std + 1)]
    return any([re.search(re.escape(x), string) for x in tokens])
