# -*- coding: utf-8 -*-

"""
主题: generic模块单元测试
日期: 2017/12/13
python: 3.6.3_64bit
"""

import unittest
from unittest.mock import patch
from yaml.constructor import ConstructorError
from aseshms import PKGINFO
from aseshms.generic import get_files, get_folder, find_files, find_file, \
    find_folders, find_folder, get_files_dir, load_yaml, convCharFull2Half, \
    validate_yaml, reflow_list, regex_flag2int, search_partial
from aseshms.util import YamlValidator, PdfParserYamlValidator


# ------------------generic module------------------------------
class TestGuiGetFiles(unittest.TestCase):
    def setUp(self):
        pass

    @patch('aseshms.generic._openfiles')
    def test_get_files_2_siblings(self, mock_openfiles):
        mock_openfiles.return_value = ('c:/a.pdf', 'c:/b.pdf')
        files = get_files()
        self.assertEqual(
            files, {'dir': 'c:/', 'files': ('c:/a.pdf', 'c:/b.pdf')})

    @patch('aseshms.generic._openfiles')
    def test_get_files_1(self, mock_openfiles):
        mock_openfiles.return_value = ('c:/a.pdf', )
        files = get_files()
        self.assertEqual(
            files, {'dir': 'c:/', 'files': ('c:/a.pdf', )})

    @patch('aseshms.generic._openfiles')
    def test_get_files_0(self, mock_openfiles):
        mock_openfiles.return_value = ''
        files = get_files()
        self.assertEqual(
            files, {'dir': None, 'files': None})

    def tearDown(self):
        pass


class TestGuiGetDir(unittest.TestCase):
    def setUp(self):
        pass

    @patch('aseshms.generic._opendir')
    def test_get_folder(self, mock_opendir):
        mock_opendir.return_value = ('c:/')
        dir = get_folder()
        self.assertEqual(dir, 'c:/')

    @patch('aseshms.generic._opendir')
    @patch('aseshms.generic._errmsg')
    def test_get_folder_err(self, mock_opendir, mock_showerr):
        mock_opendir.return_value = ('c:/', 'd:/')
        get_folder()
        mock_showerr.assert_called()
        self.assertRaises(TypeError)

    @patch('aseshms.generic._opendir')
    def test_get_folder_0(self, mock_opendir):
        mock_opendir.return_value = ''
        dir = get_folder()
        self.assertEqual(dir, '')

    def tearDown(self):
        pass


class TestFindFilesDirs(unittest.TestCase):
    def setUp(self):
        global sep
        sep = PKGINFO['dir_sep']

    def test_find_files(self):
        files = find_files('*.pdf', sep.join(['aseshms', 'testcase']))
        file_idx = [format(i, '02d') for i in range(1, 19)]
        files_should = [sep.join(['aseshms', 'testcase', 'pdf', pdfname]) for
                        pdfname in [''.join(['sample', idx, '.pdf']) for
                                    idx in file_idx]]
        self.assertEqual(files, files_should)

    def test_find_file_1(self):
        files = find_file('*.pdf', sep.join(['aseshms', 'testcase', 'pdf']), 1)
        self.assertEqual(files, sep.join(['aseshms', 'testcase', 'pdf',
                                          'sample02.pdf']))

    def test_find_folders(self):
        dirs = find_folders('*', sep.join(['aseshms', 'testcase']))
        self.assertEqual(dirs,
                         [sep.join(['aseshms', 'testcase', 'pdf']),
                          sep.join(['aseshms', 'testcase', 'yaml'])])

    def test_find_folder_1(self):
        dirs = find_folder('*', 'aseshms', 1)
        self.assertEqual(dirs, sep.join(['aseshms', 'testcase']))

    def tearDown(self):
        pass


class TestGetDirFromFiles(unittest.TestCase):
    def setUp(self):
        pass

    def test_getdir_from_siblings(self):
        dir = get_files_dir([r'c:/a.txt', r'c:/tmp/b.txt'])
        self.assertEqual(dir, 'c:/')

    @patch('aseshms.generic._warnmsg')
    def test_getdir_from_strangers(self, mock_warn):
        self.assertEqual(get_files_dir(['c:/a.txt', 'h:/b.txt']), '')
        mock_warn.assert_called()

    def tearDown(self):
        pass


class TestYamlLoader(unittest.TestCase):
    def setUp(self):
        pass

    def test_load_yaml(self):
        yml = load_yaml(file='aseshms/testcase/yaml/right.yml')
        self.assertEqual(yml, {'a': [1, 2], 'b': {'A': 3, 'B': 4}})

    def test_load_yaml_dup(self):
        self.assertRaises(ConstructorError, load_yaml, None,
                          'aseshms/testcase/yaml/dupkeys.yml')

    def test_load_yaml_invalid(self):
        self.assertRaises(ValueError, load_yaml, None, 'c:/not_exist.yml')

    def tearDown(self):
        pass


class TestCharFull2Half(unittest.TestCase):
    def setUp(self):
        pass

    def test_conv_char_full2half(self):
        self.assertEqual(convCharFull2Half(u'ＡａBb'), 'AaBb')
        self.assertEqual(convCharFull2Half(u'中文．'), u'中文.')

    def tearDown(self):
        pass
# ------------------util module---------------------------


class TestPkgEnvInfo(unittest.TestCase):
    def setUp(self):
        pass

    def test_pkginfo_keys(self):
        keys = set(PKGINFO.show().keys())
        self.assertEqual(keys,
                         set(['cwdir', 'arch', 'system', 'machine',
                              'python_version', 'aetna_build', 'username',
                              'xpdfdir', 'dir_sep', 'pdftotext', 'pdfinfo',
                              'pdftohtml', 'pdftopng', 'pdftoppm', 'pdftops',
                              'pdfimages', 'pdffonts', 'pdfdetach']))

    def test_pkginfo_valid_key(self):
        self.assertIn(PKGINFO['aetna_build'], [True, False])

    def test_pkginfo_invalid_key(self):
        with self.assertRaises(KeyError):
            PKGINFO['totally_for_unittest_only']

    def test_pkginfo_reset(self):
        PKGINFO['new_key'] = 'test'
        self.assertEqual(PKGINFO['new_key'], 'test')
        PKGINFO.reset()
        self.assertIsNone(PKGINFO.get('new_key'))

    def tearDown(self):
        pass


class TestPdfParserYamlValidator(unittest.TestCase):
    def setUp(self):
        global yml
        yml = YamlValidator('aseshms/testcase/yaml/right.yml')

    def test_validate_pdfparser_template(self):
        yml = PdfParserYamlValidator(file='aseshms/testcase/yaml/template.yml')
        yml.validate()
        self.assertTrue(yml.validation)

    def test_validate_yaml(self):
        yml_check = validate_yaml(None, 'pdfparser')
        self.assertTrue(yml_check)

    def tearDown(self):
        pass


class TestReflowList(unittest.TestCase):
    """Test the function reflow_list
    """
    def setUp(self):
        pass

    def test_reflow_correct(self):
        lst = ['A', 'B', 'C', '1.1']
        header = {'pattern': '', 'group': [0, 1, 2, 3],
                  'label': ['a', 'b', 'c', 'd'], 'default': None}
        validate = ['^\w+$', '', '', '^[\d\.]+$']
        newlst = reflow_list(lst, header, validate)
        self.assertEqual(newlst, ['A', 'B', 'C', '1.1'])

    def test_reflow_pushfwd(self):
        lst = ['A', '', '1.1']
        header = {'pattern': '', 'group': [0, 1, 2, 3],
                  'label': ['a', 'b', 'c', 'd'], 'default': None}
        validate = ['^\w+$', '^[\w\d]+$', '^[\w\d]+$', '^[\d\.]+$']
        newlst = reflow_list(lst, header, validate)
        self.assertEqual(newlst, ['A', '', '', '1.1'])

    def test_reflow_insert(self):
        lst = ['A', '', '1.1']
        header = {'pattern': '', 'group': ['row', 1, 2, 3],
                  'label': ['row', 'b', 'c', 'd'],
                  'default': ['RowId', '', '', '']}
        validate = ['^\w+$', '', '^\w+$', '^[\d\.]+$']
        newlst = reflow_list(lst, header, validate)
        self.assertEqual(newlst, ['RowId', '', '', '1.1'])

    def test_reflow_invalid_arg(self):
        lst = ['A', '', '1.1']
        header = ['a', 'b']
        validate = ['^\w+$', '', '^\w+$', '^[\d\.]+$']
        with self.assertRaises(AssertionError):
            reflow_list(lst, header, validate)

    def tearDown(self):
        pass


class TestRegexFlag(unittest.TestCase):
    def setUp(self):
        pass

    def test_regex_flag(self):
        self.assertEqual(regex_flag2int('a'), 256)
        self.assertEqual(regex_flag2int('mm'), 8)

    def test_regex_flat_invalid(self):
        with self.assertRaises(ValueError):
            regex_flag2int('Y')

    def tearDown(self):
        pass


class TestSearchPartial(unittest.TestCase):
    def setUp(self):
        pass

    def test_search_par(self):
        self.assertEqual(search_partial('abc', 'abdd', 0.5), True)
        self.assertEqual(search_partial('abc', 'man', 0.3), True)
        self.assertEqual(search_partial('(ab)c', '(saab)', 0.5), True)
        self.assertEqual(search_partial('', ' ', 0.5), True)
        self.assertEqual(search_partial('abc', 'abec', 1), False)

    def test_search_par_invalid(self):
        with self.assertRaises(AssertionError):
            search_partial(None, 2, 'a')

    def tearDown(self):
        pass


# ------------------Main call-----------------------------
if __name__ == '__main__':
    unittest.main()
