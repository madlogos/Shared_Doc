#! C:/Docs/Continuum/Anaconda3/python.exe
# -*- coding: utf-8 -*-

"""
主题: generic模块单元测试
日期: 2017/12/13
python: 3.6.3_64bit
"""

import unittest
import unittest.mock
import aseshms
from ..generic import *

class TestGetFiles(unittest.TestCase):
    def setUp(self):
        print('')
        
        

        
if __name__ == '__main__':
    unittest.main()