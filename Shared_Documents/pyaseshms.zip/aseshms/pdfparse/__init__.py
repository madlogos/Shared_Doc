# -*- coding: utf-8 -*-

__all__ = ['convpdf', 'parsetxt', 'parsepdf']

# ----------------------Import pakcakges-------------------------------
import pandas as pd
import os
import re
import tkinter as tk
import traceback

import aseshms
from aseshms.pdfparse import convpdf
from aseshms.pdfparse import parsetxt

# -----------------------parse pdfs----------------------------------


def parsepdf(pdfs=None, conv_mode="-table", return_value=False,
             keep_medium=True):
    """
    解析pdf并提取结构化数据。pdf转化为txt，基于模板template.yml解析txt，
    提取元数据重命名原始文件，并将结果输出到xlsx
    返回Dict: {'path': 文件目录, 'txt_src': 来源, 'pdf_info': pdf元数据,
              'txt_df': 抽取的txt (DataFrame)}
    pdfs: pdf文件路径列表，如为None，则启动GUI向导
    conv_mode: 可选["-layout", "-nopkbrk", " ", "-table", "-raw", "-simple"]
    return_value: 是否返回解析出来的Dict
    keep_medium: 是否保留解析出的中介产物(如txt)
    """
    root_tk = tk.Tk()
    root_tk.withdraw()
    # convert pdfs
    pdf_path, pdf_files, pdf_info = convpdf.pdf2txt(
        pdfs, mode=conv_mode).values()
    txts = [re.sub(r'.pdf$', r'.txt', pdf) for pdf in pdf_files]
    # parse txts
    txt_path, txt_files, txt_src, txt_df = parsetxt.parsetxt(txts).values()
    pdf_info['Filename'] = pd.Series(txt_src, index=pdf_info.index)
    meta_info = [re.split('_', txt_src[i]) for i in range(0, len(txt_src))]
    meta_info = pd.DataFrame(data=meta_info,
                             columns=['UserName', 'CertNum', 'Gender', 'Age',
                                      'GenDate', 'SerialNum'])
    pdf_info = pdf_info.join(meta_info)
    # rename files
    try:
        for i in range(len(pdf_files)):
            os.rename(pdf_files[i], pdf_path + txt_src[i] + ".pdf")
            if keep_medium:
                os.rename(txt_files[i], txt_path + txt_src[i] + ".txt")
            else:
                os.remove(txt_files[i])
        xlwriter = pd.ExcelWriter(pdf_path + aseshms.PKGINFO.dir_sep +
                                  "pdfInfo.xlsx", engine='xlsxwriter')
        pdf_info.to_excel(xlwriter, 'Meta',
                          index_label=["Idx", pdf_info.columns.tolist()])
        txt_df.to_excel(xlwriter, 'Data',
                        index_label=["Idx", txt_df.columns.tolist()])
        xlwriter.save()
        print(u'pdf和txt已改名。pdfInfo.xlsx已生成。')
    except SystemExit:
        pass
    except Exception:
        traceback.print_exc()
    if return_value:
        return {'path': txt_path, 'txt_src': txt_src, 'pdf_info': pdf_info,
                'txt_df': txt_df}
    root_tk.destroy()
