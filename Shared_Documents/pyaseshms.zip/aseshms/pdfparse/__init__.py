
__all__ = ['get_pdfmeta', 'rename_pdf_with_meta', 'extract_pdf']

# ----------------------Import pakcakges-------------------------------
import pandas as pd
import os
import re
import tkinter as tk
import traceback

import aseshms
from aseshms import util as au
from aseshms.pdfparse import convpdf
from aseshms.pdfparse import parsetxt


# -----------------------parse pdfs----------------------------------
def get_pdfmeta(pdfs=None, conv_mode="-table", template=None):
    """
    解析pdf并提取有意义的元数据。将pdf转化为txt，基于模板yml解析txt，提取元数据。
    提取完成后，删除转化中介txt文件。

    Args:
        pdfs: pdf文件路径列表，如为None，则启动GUI向导
        conv_mode: 可选["-layout", "-nopgbrk", " ", "-table", "-raw", "-simple"]
        template: 识别模板yaml的路径，默认None，即调用内置模板

    Returns:
        Dict: {'path': 文件目录, 'txt_src': 来源, 'pdf_info': pdf元数据,
            'pdf_files': pdf文件名}
        其中, pdf_info的列为: 'UserName', 'CertNum', 'EENum', 'Gender', 'Age',
            'Provider', 'DateOfSvc', 'SerialNum', 'Mobile'
    """
    root_tk = tk.Tk()
    root_tk.withdraw()
    # convert pdfs
    pdf_path, pdf_files, pdf_info = convpdf.pdf2txt(
        pdfs, mode=conv_mode).values()
    txts = [re.sub(r'.pdf$', r'.txt', pdf) for pdf in pdf_files]
    # validate templates
    if template is None:
        yml_cfg = au.PdfParserYamlValidator()
    else:
        yml_cfg = au.PdfParserYamlValidator(file=template)
    yml_cfg.validate()
    # parse txts
    txt_path, txt_files, txt_src, txt_df = parsetxt.parsetxt(
        txts, template=template, parse_data=False).values()
    pdf_info['Filename'] = pd.Series(txt_src, index=pdf_info.index)
    meta_info = [re.split('_', txt_src[i]) for i in range(0, len(txt_src))]
    meta_info = pd.DataFrame(data=meta_info,
                             columns=['UserName', 'CertNum', 'EENum', 'Gender',
                                      'Age', 'Provider', 'DateOfSvc',
                                      'SerialNum', 'Mobile'])
    pdf_info = pdf_info.join(meta_info)
    pdf_info.index = range(len(pdf_info.index))
    # delete txts
    for txtfile in txt_files:
        os.remove(txtfile)
    return {'path': txt_path, 'txt_src': txt_src, 'pdf_info': pdf_info,
            'pdf_files': pdf_files}
    root_tk.destroy()


def rename_pdf_with_meta(pdfs=None, conv_mode="-table", template=None):
    """
    解析pdf并提取有意义的元数据，将pdf重命名。
    将pdf转化为txt，基于模板yml解析txt，提取元数据。提取完成后，删除转化中介txt文件。

    Args:
        pdfs: pdf文件路径列表，如为None，则启动GUI向导
        conv_mode: 可选["-layout", "-nopgbrk", " ", "-table", "-raw", "-simple"]
        template: 识别模板yaml的路径，默认None，即调用内置模板

    Returns:
        None
    """
    dict_rslt = get_pdfmeta(pdfs=pdfs, conv_mode=conv_mode, template=template)
    pdf_files = dict_rslt['pdf_files']
    txt_src = dict_rslt['txt_src']
    for i in range(len(pdf_files)):
        os.rename(pdf_files[i], dict_rslt['path'] + '/' + txt_src[i] + ".pdf")
    print(''.join(["A total of ", str(len(pdf_files)),
                   " pdfs have been renamed with their meta data: \n",
                   "'姓名_证件_工号_性别_年龄_服务机构_服务日期_体检号_联系电话'\n",
                   "Note: some of the fields ",
                   "may be omitted since they do not contain info."]))


def extract_pdf(pdfs=None, conv_mode="-table", template=None,
                return_value=False, output_excel=True, keep_intermed=True):
    """
    解析pdf并提取结构化元数据及明细。
    pdf转化为txt，基于模板yml解析txt，提取元数据重命名原始文件，并可将结果输出到xlsx。
    是`rename_pdf_with_meta`的升级版。

    Args:
        pdfs (list): pdf文件路径列表，如为None，则启动GUI向导
        conv_mode (str): 可选["-layout", "-nopgbrk", " ", "-table", "-raw",
            "-simple"]
        template (str): 识别模板yaml的路径，默认None，即调用内置模板
        return_value (bool): 是否返回解析出来的Dict，默认False
        output_excel (bool): 是否将解析明细输出为excel，默认为True
        keep_intermed (bool): 是否保留解析出的中介产物(如txt)，默认True

    Returns:
        (如return_value为True) Dict: {'path': 文件目录, 'txt_src': 来源,
            'pdf_info': pdf元数据, 'txt_df': 抽取的txt (DataFrame)}
        其中, pdf_info的列为: 'UserName', 'CertNum', 'EENum', 'Gender', 'Age',
            'Provider', 'DateOfSvc', 'SerialNum', 'Mobile'
    """
    root_tk = tk.Tk()
    root_tk.withdraw()
    # convert pdfs
    pdf_path, pdf_files, pdf_info = convpdf.pdf2txt(
        pdfs, mode=conv_mode).values()
    txts = [re.sub(r'.pdf$', r'.txt', pdf) for pdf in pdf_files]
    # validate templates
    if template is None:
        yml_cfg = au.PdfParserYamlValidator()
    else:
        yml_cfg = au.PdfParserYamlValidator(file=template)
    yml_cfg.validate()
    # parse txts
    txt_path, txt_files, txt_src, txt_df = parsetxt.parsetxt(
        txts, template=template).values()
    pdf_info['Filename'] = pd.Series(txt_src, index=pdf_info.index)
    meta_info = [re.split('_', txt_src[i]) for i in range(0, len(txt_src))]
    meta_info = pd.DataFrame(data=meta_info,
                             columns=['UserName', 'CertNum', 'EENum', 'Gender',
                                      'Age', 'Provider', 'DateOfSvc',
                                      'SerialNum', 'Mobile'])
    pdf_info = pdf_info.join(meta_info)
    pdf_info.index = range(len(pdf_info.index))
    # rename files
    try:
        dirsep = aseshms.PKGINFO['dir_sep']
        for i in range(len(pdf_files)):
            os.rename(pdf_files[i], dirsep.join(pdf_path, txt_src[i] + ".pdf"))
            if keep_intermed:
                os.rename(txt_files[i], dirsep.join(txt_path,
                                                    txt_src[i] + ".txt"))
            else:
                os.remove(txt_files[i])
        if output_excel:
            xlwriter = pd.ExcelWriter(dirsep.join([pdf_path, "pdfInfo.xlsx"]),
                                      engine='xlsxwriter')
            pdf_info.to_excel(xlwriter, 'Meta',
                              index_label=["Idx", pdf_info.columns.tolist()])
            txt_df.to_excel(xlwriter, 'Data',
                            index_label=["Idx", txt_df.columns.tolist()])
            xlwriter.save()
            print(u'pdf和txt已改名。pdfInfo.xlsx已生成。')
        else:
            print(u'pdf和txt已改名。')
    except SystemExit:
        pass
    except Exception:
        traceback.print_exc()
    if return_value:
        return {'path': txt_path, 'txt_src': txt_src, 'pdf_info': pdf_info,
                'txt_df': txt_df}
    root_tk.destroy()


# -----------------------main call------------------------
if __name__ == "main":
    extract_pdf()
