# -*- coding: utf-8 -*-

"""
主题: pdfparse模块单元测试
日期: 2018/1/23
python: 3.6.3_64bit
"""

import unittest
import os
import shutil
from aseshms.pdfparse import convpdf
from aseshms.pdfparse import parsetxt
from aseshms import generic as ag


# ------------------convpdf module------------------------------
class TestPdfParser(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.pdf = convpdf.PdfParser(file='aseshms/testcase/pdf/sample01.pdf')

    def test_get_meta(self):
        self.pdf.getMeta()
        bench = {'Title': '无标题页', 'Creator': 'wkhtmltopdf 0.12.1.1',
                 'Producer': 'Qt 4.8.6', 'CreationDate': '11/23/17 13:53:28',
                 'Tagged': 'no', 'Form': 'AcroForm', 'Pages': '8',
                 'Encrypted': 'no',
                 'Page size': '595 x 842 pts (A4) (rotated 0 degrees)',
                 'File size': '777701 bytes', 'Optimized': 'no',
                 'PDF version': '1.4', 'Filename': 'sample01'}
        self.assertEqual(self.pdf.meta, bench)

    def test_conv_txt_sample1(self):
        self.pdf.convertToTxt()
        self.assertTrue(os.path.exists('aseshms/testcase/pdf/sample01.txt'))
        try:
            with open('aseshms/testcase/pdf/sample01.txt',
                      encoding="UTF-8") as f:
                txt = f.read()
        except Exception:
            raise
        self.assertEqual(len(txt), 8703)

    def test_conv_html_sample1(self):
        self.pdf.convertToHtml()
        self.assertTrue(os.path.exists('aseshms/testcase/pdf/sample01'))
        try:
            pngs = ag.find_files('*.png', 'aseshms/testcase/pdf/sample01')
            self.assertEqual(len(pngs), 8)
            htmls = ag.find_files('*.html', 'aseshms/testcase/pdf/sample01')
            self.assertEqual(len(htmls), 9)
        except Exception:
            raise

    @classmethod
    def tearDownClass(cls):
        os.remove('aseshms/testcase/pdf/sample01.txt')
        shutil.rmtree(os.path.realpath('aseshms/testcase/pdf/sample01'),
                      ignore_errors=True)


class TestBatchPdfConv3(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.pdfs = ['aseshms/testcase/pdf/sample01.pdf',
                    'aseshms/testcase/pdf/sample02.pdf',
                    'aseshms/testcase/pdf/sample03.pdf']

    def test_invalid_towhat(self):
        with self.assertRaises(ValueError):
            convpdf.convert_pdfs(self.pdfs, towhat="aaa")

    def test_invalid_pdfs(self):
        with self.assertRaises(ValueError):
            convpdf.convert_pdfs(['c:/blabla.pdf'])

    def test_conv_pdfs(self):
        out = convpdf.convert_pdfs(self.pdfs)
        self.assertEqual(out['pdf_path'], 'aseshms/testcase/pdf')
        self.assertEqual(list(out['pdf_info']['Creator']),
                         ['wkhtmltopdf 0.12.1.1', 'wkhtmltopdf 0.12.1.1',
                          'llPDFLib program'])

    @classmethod
    def tearDownClass(cls):
        for i in ('01', '02', '03'):
            os.remove(os.path.realpath('/'.join(
                ['aseshms', 'testcase', 'pdf', 'sample' + i + '.txt'])))


# ------------------parsetxt module---------------------------
class TestParseTxtMeta(type):
    """Meta class of testing framework for TxtParser objects
    `expect` is a yml file registering expected results
    """
    global expect, testlist, testcells
    # expected results for parsing each sample
    expect = ag.load_yaml(file='aseshms/testcase/pdf/testcase.yml')
    # testlist: [dict name in `expect`, object to be evaluated,
    #            before-hand command]
    testlist = [['meta', 'parser.meta', None],
                ['tplname', 'parser.tpl["name"]', None],
                ['txtlen', 'len(parser.txt)', None],
                ['sectlen', '[len(v) for v in parser.txt]', 'parser.clean()'],
                ['tblnrow', 'len(parser.tbl.index)', 'parser.parseSections()']]
    testcells = [['cell1', 'parser.tbl[u"结果"][condc & condi].item()', None],
                 ['cell2', 'parser.tbl[u"结果"][condc & condi].item()', None]]

    def __new__(cls, name, bases, dict):
        global parser, condc, condi

        def gen_test(obj, expect, attr):
            def fun(self):
                self.assertEqual(obj, expect[attr])
            return fun

        for i in range(len(expect)):
            # for i in range( ):
            pdf_file = '/'.join(['aseshms', 'testcase', 'pdf',
                                 '%s.pdf' % expect[i]['name']])
            convpdf.convert_pdfs(pdf_file)
            txt_file = '/'.join(['aseshms', 'testcase', 'pdf',
                                 '%s.txt' % expect[i]['name']])
            parser = parsetxt.TxtParser(txt_file)

            for j in range(len(testlist)):
                testitem = testlist[j][0]
                if testlist[j][2] is not None:
                    eval(testlist[j][2])
                dict['test_%s_%s' % (expect[i]['name'], testitem)] = \
                    gen_test(eval(testlist[j][1]), expect[i], testitem)
            for j in range(len(testcells)):
                testitem = testcells[j][0]
                condc = parser.tbl[u'类目'] == expect[i][testitem][0]
                condi = parser.tbl[u'项目'] == expect[i][testitem][1]
                if not any(condc & condi):
                    raise ValueError(
                        ('Did not match a row where `类目`==%r & `项目`==%r '
                         'when parsing %r for DF unittest.') %
                        (expect[i][testitem][0], expect[i][testitem][1],
                         txt_file))
                dict['test_%s_%s' % (expect[i]['name'], testitem)] = \
                    gen_test(eval(testcells[j][1]), expect[i][testitem], 2)

            os.remove(os.path.realpath(txt_file))

        return super(TestParseTxtMeta, cls).__new__(cls, name, bases, dict)


class TestTxtParserSamples(unittest.TestCase, metaclass=TestParseTxtMeta):
    def setUp(self):
        pass


# ------------------Main call-----------------------------
if __name__ == '__main__':
    unittest.main()
