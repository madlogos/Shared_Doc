# -*- coding: utf-8 -*-

"""
主题: 解析txt
日期: 2017/12/12
python: 3.6.3_64bit
"""

__all__ = ['TxtParser', 'TxtSectionParser', 'parsetxt']

# -----------------------Import packages----------------------------------
import tkinter as tk
from tqdm import tqdm
import numpy as np
import pkg_resources as pkgr
import os
import pandas as pd
# import pdb
import re
import sys
import time
import traceback
import warnings

import aseshms
from aseshms import generic as ag


# ---------------------------Class------------------------------------
class TxtParser(object):
    """
    Text Parser. After loading a txt file, it searches the yml template to get
    a match, then get the meta info. You can then clean it, and then parse the
    sections.

    Attributes:
        txtfile (str): path of the text file
        encoding (str): encoding for reading txtfile, default 'utf-8'
        txt (str): raw txt loaded from txtfile
        tpl (dict): dict matched and extracted from templates
        meta (dict): meta info of the txt parser
        source (str): concatenated str of meta
        tbls (list): list of pandas.DataFrame parsed from txt
        tbl (DataFrame): concatenated pandas.DataFrame parsed from self.tbls
        sections (dict): parsed sections with meta info. {'catg': str,
            'type': str, 'header': list, 'body': list}
    """
    def __init__(self, file, template=None, encoding='UTF-8'):
        """
        __Init__ method of TxtParser

        Args:
            file (str): the path of the txt file to parse
            template (str, optional): the path of the yml template, default
                None (internal)
            encoding (str, optional): default 'UTF-8'
        """
        self.txtfile = file
        self.encoding = encoding
        if template is None:
            self._tpls = ag.load_yaml(pkgr.resource_stream(
                    "aseshms", "pdfparse/template.yml"))
        else:
            if not template.lower().endswith(('.yml', '.yaml')) or \
              not os.path.isfile(template):
                print(u'模板template必须是有效存在的yml文件。请手动选择一个。')
                template = ag.get_yaml(multi=False)
            with open(template, 'r', encoding='UTF-8') as f:
                self._tpls = ag.load_yaml(f)
        self.readTxt('read', force_half_char=True)
        if self.txt is not None:
            self.stripEmptyLines()
        self.searchTemplate()
        self.getMeta()

    def clean(self):
        """
        Replace the words based on 'repl' field of the template, split the txt
        into sections on '@=v=@', finally, check if the residual of the text is
        up to >60% of the original length.
        """
        if not isinstance(self.txt, str):
            raise TypeError('self.txt must a string. readTxt() first.')
        orig_len = len(self.txt)
        self.replaceWords()
        self.txt = re.split(r'@=v=@', self.txt)
        self.txt = [sect for sect in self.txt if
                    not re.search(r'@=x=@', sect) and sect != '']
        new_len = sum([len(x) for x in self.txt])
        if orig_len > 0:
            if new_len/orig_len < 0.6:
                warnings.warn('%3.2f' % (100*(1-new_len/orig_len)) +
                              r'% content dropped.')

    def readTxt(self, mode='read', force_half_char=True):
        """
        Internal method to read self.txt, and convert full characters to half.

        Args:
            mode (str, optional): one of ['read', 'readline', 'readlines'],
                default 'read'
            force_half_char (bool, optional): whether coerse full characters to
                half characters. Default True.
        """
        READ_MODE = ('read', 'readline', 'readlines')
        if mode not in READ_MODE:
            raise ValueError("mode: must be of one value in %r." % READ_MODE)
        with open(self.txtfile, encoding=self.encoding) as f:
            try:
                if mode == 'read':
                    self.txt = f.read()
                    if force_half_char:
                        self.txt = ag.convCharFull2Half(self.txt)
                elif mode == 'readline':
                    self.txt = list()
                    for line in open(self.txtfile):
                        line = f.readline()
                        if force_half_char:
                            line = ag.convCharFull2Half(line)
                        self.txt.append(line)
                elif mode == "readlines":
                    self.txt = f.readlines()
                    if force_half_char:
                        for line in self.txt:
                            line = ag.convCharFull2Half(line)
            except Exception:
                raise
                traceback.print_exc()
                self.txt = None

    def show(self):
        """Display self.txt
        """
        return self.txt

    def stripEmptyLines(self):
        """Strip the empty lines in self.txt
        """
        if isinstance(self.txt, str):
            self.txt = re.sub(r'(\r *\n){2,}|\n{2,}|\n *\n', r'\n', self.txt)

    def __repr__(self):
        return self.txtfile + '\n' + str(self.txt)

    def searchTemplate(self):
        """Search the template to match a pattern as self.tpl
        """
        self.tpl = list()
        for tpl in self._tpls:
            rules = tpl['rule']
            try:
                if all([re.search(rules[i], self.txt) for i in
                        range(len(rules))]):
                    self.tpl.append(tpl)
            except Exception:
                pass
        if len(self.tpl) < 1:
            raise Exception('Did not find any template for %s. ' %
                            os.path.realpath(self.txtfile) +
                            '\nPlease refine template.yml.')
        elif len(self.tpl) > 1:
            raise Exception('Too many templates found in match of the doc %s. '
                            % os.path.realpath(self.txtfile) +
                            '\nPlease refine template.yml.')
        else:
            self.tpl = self.tpl[0]

    def _getMeta(self, field):
        """If meta in template has a tuple/list index for extraction,
        then return a list, else a character.
        Meta info will be used to rename files, so <>\/*":?| will be replaced
            with 'x'.

        Args:
            field (str): field name of the meta info

        Returns:
            meta field value. If nothing is extracted, returns ''.
        """
        metas = self.tpl['meta']
        try:
            result = re.search(metas[field][0], self.txt).groups()
            if isinstance(metas[field][1], (tuple, list)):
                return [re.sub(r'[\<\>\\/\*\"\:\?\|]', 'x', result[x])
                        for x in [metas[field][1]]]
            else:
                return re.sub(r'[\<\>\\/\*\"\:\?\|]', 'x',
                              result[metas[field][1]])
        except SystemExit:
            pass
        except Exception:
            return ''

    def getMeta(self):
        """
        Get meta info using _getMeta. The meta info dict's keys are:
            Name, Gender, Age, CertNum, Provider, RegDate, RecId, Tel
        """
        if not hasattr(self, 'tpl'):
            raise AttributeError('`tpl` attribute not assigned. '
                                 'searchTemplate() first.')
        self.meta = dict()
        self.meta['Name'] = self._getMeta("Name")
        self.meta['Gender'] = self._getMeta("Gender").replace(u'女士', u'女') \
            .replace(u'先生', u'男')
        self.meta['Age'] = self._getMeta("Age")
        self.meta['CertNum'] = self._getMeta("CertNum")
        self.meta['EENum'] = self._getMeta("EENum")
        if self.tpl['provider'] is None:
            self.meta['Provider'] = self.tpl['name']
        else:
            self.meta['Provider'] = self.tpl['provider']
        self.meta['Provider'] = re.sub(r'[\<\>\\/\*\"\:\?\|]', 'x',
                                       self.meta['Provider'])
        yr = self._getMeta("Yr")
        mo = re.sub(r'^(\d)$', r'0\1', self._getMeta("Mo"))
        dt = re.sub(r'^(\d)$', r'0\1', self._getMeta("Dt"))
        self.meta['RegDate'] = "".join([yr, mo, dt])
        self.meta['RecId'] = self._getMeta("RecId")
        self.meta['Tel'] = self._getMeta("Tel")
        self.source = '_'.join([self.meta[attr] for attr in
                               ['Name', 'CertNum', 'EENum', 'Gender', 'Age',
                                'Provider', 'RegDate', 'RecId', 'Tel']])

    def replaceWords(self):
        """Replace the words in self.txt based on repl field in the template
        """
        if not hasattr(self, 'tpl'):
            raise AttributeError('`tpl` attribute not assigned. '
                                 'searchTemplate() first.')
        for repl in self.tpl['repl']:
            if len(repl) == 2:
                self.txt = re.sub(repl[0], repl[1], self.txt)
            elif len(repl) == 3:
                self.txt = re.sub(repl[0], repl[1], self.txt,
                                  flags=ag.regex_flag2int(repl[2]))

    def parseSections(self):
        """Loop the text secions, set each section as TxtSectionParser, and
        parse them based on yml template. `splitBody()`, `transposeArray()`,
        `validateFields()` and `makeTable()` are used.
        """
        if not isinstance(self.txt, list):
            raise TypeError('`self.txt` must be of type `list`. '
                            'splitBody() first.')
        self.tbls = []
        self.sections = []
        for txtsection in self.txt:
            try:
                section = TxtSectionParser(txtsection, self.tpl)
                # initialization
                section.searchType()
                if section.type is None or not isinstance(section.type, str):
                    section.catg = section.header = section.header_label = \
                        section.tbl = None
                    section.body = re.sub(' +', ' ', section.txt)
                else:
                    section.modulize()
                    section.replaceWords()
                    section.concatUp()
                    section.concatDown()
                    # conversion
                    section.splitBody()
                    section.transposeArray()
                    section.validateFields()
                    section.makeTable()
                    self.tbls.append(section.tbl)
                self.sections.append(
                    {'type': section.type, 'catg': section.catg,
                     'header': section.header_label, 'body': section.body,
                     'origbody': section.origbody, 'txt': section.txt})
            except Exception:
                warnings.warn('Failed to parse section %r of %s' %
                              (str(section), self.txtfile))
                raise
        # concat the list to a DF
        # pdb.set_trace()
        self.tbl = pd.concat(self.tbls)
        col_head = list(self.tbl.columns.values)
        col_head = col_head.insert(0, u'来源')
        self.tbl[u'来源'] = pd.Series(self.source, index=self.tbl.index)
        self.tbl.reindex(columns=col_head)
        self.tbl.index = range(len(self.tbl.index))


class TxtSectionParser(object):
    """
    Wrapper for txt sections to parse.

    1) It accepts text sections splitted by `TxtParser.clean()`.
    2) It then matches template (`searchTemplate()`);
    3) modulize it into head and body (`modulize()`);
    4) replace the words inside the section (`replaceWords()`);
    5) combine neighboring lines if necessary (`concatUp()` and
        `concatDown()`) and then:
    6) you can split the body (`splitBody()`);
    7) transpose it (`transposeArray()`) and;
    8) validate fields (`validateFields()`);
    9) finally convert it into pandas.DataFrame (`makeTable()`).

    Attributes:
        cfg (dict): configurations. Default {'return_self': False}. If
            'return_self' is True, then all the methods will return self, which
            means, you can pipe methods (obj.method1().mothod2())
        txt (str): a text section for parsing.
        tpl (dict): parsed yml PdfParser template.
        type (str): the name of the dict in 'sect' part of the yml template.
        header (list): the header of the section, used for DataFrame columns
        body (str/list): the txt seperated for split, transpose and pattern
            matching. The final output is a nested list.
        origbody (list): the original body yielded from `splitBody()`.
        catg (str): the category of the section. E.g., catg of `WBC`, `RBC` is
            `blood routine`
        tbl: pandas.DataFrame yielded after parsing the txt section
    """
    def __init__(self, txt, tpl, cfg={'return_self': False}):
        """__Init__ method of TxtSectionParser

        Args:
            txt (str): a text section.
            tpl (dict): parsed yml PdfParser template.
        """
        if isinstance(txt, (tuple, list)):
            self.txt = r"\r\n".join(txt)
        else:
            self.txt = txt
        self.txt = re.sub(r'(\n *\n)+', r'\n', self.txt)
        self.tpl = tpl
        self.cfg = cfg
        self.tbl = None

    def __repr__(self):
        if self.tbl is None:
            return self.txt
        else:
            return r'\n'.join([self.type, str(self.tbl)])

    def searchType(self):
        """Search the section type based on the template as self.type
        """
        self.type = list()
        for type, rules in self.tpl['sect'].items():
            try:
                if len(rules['header']['pattern']) == 1:
                    if re.search(rules['header']['pattern'][0], self.txt):
                        self.type.append(type)
                elif len(rules['header']['pattern']) == 2:
                    if re.search(rules['header']['pattern'][0], self.txt,
                                 ag.regex_flag2int(
                                    rules['header']['pattern'][1])):
                        self.type.append(type)
            except Exception:
                pass
        if len(self.type) < 1:
            # raise Exception('Did not match any header pattern for text %r.' %
            #                 self.txt)
            self.type = None
        elif len(self.type) > 1:
            # raise Exception(
            #     ('Too many header patterns found in match of the text %r.' +
            #      'Please refine the template.') % self.txt)
            self.type = self.type
        else:
            self.type = self.type[0]
        if self.cfg['return_self']:
            return self

    def modulize(self):
        """Split self.txt into header and body, with a category (dept) tag
        """
        if not hasattr(self, 'type'):
            raise AttributeError(('`type` attribute not assigned. '
                                  'searchType() first.'))
        header = self.tpl['sect'][self.type]['header']
        catg = self.tpl['sect'][self.type]['category']
        try:
            if len(header['pattern']) == 1:
                header_grp = self.header = re.search(
                    header['pattern'][0], self.txt).groups()
            elif len(header['pattern']) == 2:
                header_grp = self.header = re.search(
                    header['pattern'][0], self.txt, ag.regex_flag2int(
                        header['pattern'][1])).groups()
            # remove blanks in header
            self.header = [re.sub(' +', '', x) for x in self.header]
            self.header_label = self.tpl['sect'][self.type]['header'][
                'label'].copy()
            if not isinstance(header['group'], (tuple, list)):
                header['group'] = [header['group'], ]
            self.header = [self.header[x] if isinstance(x, int) else x
                           for x in header['group']]
            if len(self.header) < 1:
                raise ValueError(('Modulization failed in matching header of '
                                  '%r. Check the template.') % self.txt)
            self.catg = re.search(catg[0], self.txt).groups()
            if len(self.catg) < 1:
                raise ValueError(('Modulization failed in matching catg of '
                                  '%r. Check the template.') % self.txt)
            # if catg's grouping rule is a list/tuple, match them
            if isinstance(catg[1], (tuple, list)):
                self.catg = [self.catg[x] for x in catg[1]]
            else:
                self.catg = [self.catg[x] for x in [catg[1]]]
            self.catg = [re.sub(' +', '', x) for x in self.catg]
            # remove header and above from body
            header_idx = self.tpl['sect'][self.type]['header']['group']
            header_idx = [i for i in range(len(header_idx)) if
                          isinstance(header_idx[i], int)]

            self.body = re.sub(
                r'^[^\n\r]*?[\r\n]* *(' + re.sub(
                    '([\(\)\{\}\[\]\-])', r'\\\1',
                    ' *'.join([self.header[i] for i in header_idx]) + '|' +
                    ' *'.join(header_grp)) + r') *([\r\n]+|$)',
                '', self.txt, flags=re.DOTALL)
            if self.cfg['return_self']:
                return self
        except SystemExit:
            pass
        except Exception:
            warnings.warn(
                ('Section "%r" failed to be modulized with %s,' +
                 '(header "%s", category "%s"). Check the template.') %
                (self.txt, self.type, str(self.header), str(self.catg)))
            raise
            traceback.print_exc()

    def replaceWords(self):
        """Replace the words in self.body based on repl field in the template's
            `section` field
        """
        repl = self.tpl['sect'][self.type]['repl']
        if repl is None:
            return
        for repllst in repl:
            assert isinstance(repllst, list) and isinstance(repllst[0], str) \
                and isinstance(repllst[1], str)
            if len(repllst) == 2:  # no re.flag in template
                self.body = re.sub(repllst[0], repllst[1], self.body)
            elif len(repllst) >= 3:  # there is re.flag in template
                self.body = re.sub(repllst[0], repllst[1], self.body,
                                   flags=ag.regex_flag2int(repllst[2]))
        if self.cfg['return_self']:
            return self

    def concatUp(self):
        """If begin_word is defined in yaml template `combine_above`,
        then combine above lines based on it.
        """
        combine_above = self.tpl['sect'][self.type]['combine_above']
        combine_keep_brk = self.tpl['sect'][self.type]['combine_keep_breaks']
        if combine_above is None:
            return
        if not isinstance(combine_above, (tuple, list)):
            combine_above = [combine_above, ]
        # if the body is a hang paragraph, move the top-grid word to start
        if re.search('^( {2,}\S[^\r\n]*[\r\n]+)+?(\S+)', self.body):
            self.body = re.sub(
                '^(?P<init>(?P<hang> {2,}\S[^\r\n]*[\r\n]+)+?)(?P<top>\S+)',
                r'\g<top>\g<init>', self.body)
        for begin_word in combine_above:
            # pdb.set_trace()
            # how many hang sections are ther following begin_word
            # how many hang sections to combine
            begin_word_section = re.search(
                '(' + begin_word + '( {2,}[^\n\r]*([\n\r]+|$))+)',
                self.body)
            if begin_word_section is None:
                continue
            else:
                begin_word_section = re.sub(
                    '(^.+)[\n\r]+$', '\1',
                    begin_word_section.groups()[0].strip())
            # line break
            line_sep = ''
            if combine_keep_brk is not None:
                if not isinstance(combine_keep_brk, (list, tuple)):
                    combine_keep_brk = [combine_keep_brk, ]
                if re.search(r'|'.join(combine_keep_brk), begin_word):
                    line_sep = '@=v=@'

            n_sections_below = len(re.split('[\n\r]+', begin_word_section)) - 1
            if n_sections_below > 0:
                # loop, combine all the hang sections above
                i = 0
                while i < n_sections_below:
                    # pdb.set_trace()
                    # if the above section has punctuations in the first 3 char
                    # it is likely the below_section of the previous item
                    prev_line = re.findall(
                        '(^|[\r\n]+) {2,}([^\n\r]+[\n\r]+)' + begin_word,
                        self.body)
                    if len(prev_line) == 0:
                        break
                    elif re.search('。[\n\r]+', prev_line[0][1]) or \
                        (re.search('^[^,;!\?。\n\r]{,5}[,;!\?。]',
                                   prev_line[0][1]) and not
                         ag.search_partial(begin_word, prev_line[0][1], 0.5)):
                        break
                    self.body = re.sub(
                        ''.join(['(?P<brk>^|[\r\n]+) {2,}',
                                 '(?P<hang>[^\n\r]*)[\r\n]+',
                                 '(?P<bword>', begin_word, ')(?P<sp> +)',
                                 '(?P<eoword>[^\n\r]+)']),
                        ''.join([r'\g<brk>\g<bword>\g<sp>\g<hang>', line_sep,
                                 r'\g<eoword>']), self.body)
                    i += 1
        if self.cfg['return_self']:
            return self

    def concatDown(self):
        """If a full line is followed by a hang line, concat the line below.
        Line breaks are replaced with @=v=@ to keep together before applying
        `splitBody()`, if is defined in yaml template `combine_keep_breaks`.
        """
        combine_keep_brk = self.tpl['sect'][self.type]['combine_keep_breaks']
        if combine_keep_brk is not None:
            if not isinstance(combine_keep_brk, (list, tuple)):
                combine_keep_brk = [combine_keep_brk, ]
        # if the section only contains one col, do not concat down
        if len(self.header) == 1:
            return
        # if there are sections begin with blanks, combine down
        while re.search(r'(^|[\r\n]+)\S+.*[\r\n]+ +\S+', self.body):
            # with combine_keep_brk, replace \n with @=v=@
            if combine_keep_brk is not None and \
              re.search(r'(^|[\r\n]+)\S*(' + r'|'.join(combine_keep_brk) +
                        r').+[\r\n]+ +\S+', self.body):
                self.body = re.sub(
                    r'(^|[\r\n]+)(\S*' + r'\s*|'.join(combine_keep_brk) +
                    r')(.+)([\r\n]+) +(\S+)',
                    r'\1\2\3@=v=@\5', self.body)
            # else, combine down and remove \n
            elif re.search(r'(^|[\r\n]+)\S+(.+)[\r\n]+ +\S+', self.body):
                self.body = re.sub(
                    r'(^|[\r\n]+)(\S+)(.+)([\r\n]+) +(\S+)',
                    r'\1\2\3\5', self.body)
            else:
                break
        if self.cfg['return_self']:
            return self

    def splitBody(self):
        """Scan the body line by line and split each line into str lists
        """
        if not all([hasattr(self, 'header'), hasattr(self, 'body')]):
            raise AttributeError('`header` or `body` attribute not assigned.'
                                 'modulize() first.')
        col_blanks = self.tpl['sect'][self.type]['col_blanks']
        if isinstance(col_blanks, str):
            col_blanks = ''.join([' {', col_blanks, '}'])
        else:
            col_blanks = r' {5,25}'
        # if the int part of the tpl['header']['group'] > 1, the body is not a
        # uniform block, split it.
        if sum([isinstance(x, int) for x in
                self.tpl['sect'][self.type]['header']['group']]) > 1:
            self.body = re.split(r'[\r\n]+', self.body)
            self.body = [line for line in self.body if line != '']
        # Split self.body line by line
        body = []
        newbody = []
        if not isinstance(self.body, list):
            self.body = [self.body, ]
        for line in self.body:
            # change @=v=@ back to line breaks
            line = re.sub(r'@=v=@', r'\n', line)
            # split the lines to a vector, remove unnecessary blanks
            line = re.split(col_blanks, line)
            if isinstance(line, list):
                line = [re.sub(r'(?<! )(?P<sp> )(?P<chr>\S)', r'\g<chr>',
                        x.strip()) for x in line]
            # call func reflow_list():
            reflow = ag.reflow_list(line,
                                    self.tpl['sect'][self.type]['header'],
                                    self.tpl['sect'][self.type]['validate'])
            body.append(line)
            newbody.append(reflow)

        self.origbody = body.copy()
        self.body = newbody.copy()
        if self.cfg['return_self']:
            return self

    def transposeArray(self):
        """Sometimes the text array should be transposed. This action is
        controlled by 'transpose' field in the template
        """
        how_transpose = self.tpl['sect'][self.type]['transpose']
        if how_transpose is not None:
            self.body = np.array(self.body).transpose()
            self.body = [' '.join(lst) for lst in self.body]
            self.body = [[self.header[i], self.body[i]] for i in
                         range(len(self.header))]
        if self.cfg['return_self']:
            return self

    def validateFields(self):
        """Validate each fields using RegEx rules mandated in 'validate' field
        in the template. If not match, label the cell 'X'; if lost some of
        the original texts, label the cell '-'.
        """
        if not hasattr(self, 'body'):
            raise AttributeError('`body` attribute not assigned. '
                                 'modulize() first.')
        if isinstance(self.body, str):
            self.body = [[self.body, ''], ]  # summary type
        if isinstance(self.body, list):
            for line in self.body:
                if isinstance(line, list):
                    line.append('')  # add a column of validate anyway
                else:
                    line = [line, '']
        validate = self.tpl['sect'][self.type]['validate']
        # begin validatiion
        if validate is None:
            return
        else:
            for i in range(len(self.body)):
                match_flag = ''  # storing validate result
                line = self.body[i]
                if not all([re.search(validate[x], str(line[x]))
                            if line[x] is not None and line[x] != '' else True
                            for x in range(len(validate))]):
                    match_flag += 'X'
                if len([x for x in line if x != '']) < len(
                  [x for x in self.origbody[i] if x != '']):
                    match_flag += '-'
                if match_flag != '':
                    self.body[i][-1] = match_flag
        if self.cfg['return_self']:
            return self

    def makeTable(self):
        """Convert the yielded array into pandas.DataFrame. Column '类目'
        is generated here based on self.catg. Column '校验' is genereated based
        on results of validateFields().
        """
        # self.body == [['', '', '']]
        if self.body == []:
            return None
        if not isinstance(self.body, list) or not isinstance(
          self.body[0], list):
            raise TypeError('`body` must be a list of lists. modulize() and '
                            'splitBody() first.')
        how_transpose = self.tpl['sect'][self.type]['transpose']
        if how_transpose is not None:
            self.header_label = how_transpose.copy()
        self.header_label.append(u'校验')

        try:
            self.tbl = pd.DataFrame.from_records(self.body,
                                                 columns=self.header_label)
            # col_head = self.tbl.columns.tolist()
            # col_head.insert(0, u'类目')
            self.tbl[u'类目'] = pd.Series(self.catg, index=self.tbl.index)
            # self.tbl = self.tbl.reindex(columns=col_head)
            self.tbl.index = range(len(self.tbl.index))
        except Exception:
            warnings.warn((u'Fail to make table for the section. '
                           u'(header "%s"; body "%s")') %
                          (str(self.header), str(self.body)))
            raise
        if self.cfg['return_self']:
            return self

    def show(self):
        """If the table is yielded, display it; else display the raw text
        """
        if self.tbl is None:
            return self.txt
        else:
            return ['[' + self.type + ']', r'\n', self.tbl]


# ---------------------------Main call----------------------------------
def parsetxt(txts=None, template=None, parse_meta=True, parse_data=True):
    """
    解析txt为表格，txts必须在同一个文件夹内

    Args:
        txts (str): txts路径，默认为None，即启动GUI向导选择
        template (str): yml模板路径，默认为None，即调用系统内置模板
        parse_meta (bool): 是否解析元数据，默认为True
        parse_data (bool): 是否解析明细，默认为True

    Returns:
        dict {'txt_path':文件夹路径txt_path, 'txt_files': 各txt文件路径,
              'txt_src': 各txt的来源信息(用于改名), 如parse_meta为False，则返回None,
              'txt_df': DataFrame txts数据}, 如parse_data为False，则返回None
        txt_df的列: ['类目', '项目', '结果', '范围', '单位', '提示', '校验', '来源']
    """
    root_tk = tk.Tk()
    root_tk.withdraw()

    gui = txts is None

    if gui:
        # 找到txts，确保文件夹内有txt
        txt_path, txts = ag.get_txts(
            initialdir=aseshms.PKGINFO['cwdir']).values()
    else:
        if not isinstance(txts, (list, tuple)):
            txts = [txts, ]
        txts = [txt for txt in txts if os.path.isfile(txt)]
        txt_path = ag.get_files_dir(txts)
        if txt_path == '':
            raise ValueError(u"txts不属于同一个文件夹。\n请注意核对。")
            return
        if len(txts) == 0:
            raise ValueError(u"路径参数txts无效，未找到任何可用的txt文件。\n请注意核对。")
            return

    # parse the txts
    parsed_data = []
    data_source = []
    values = range(len(txts))
    with tqdm(total=len(values), file=sys.stdout) as pbar:
        for i in values:
            try:
                txt = TxtParser(txts[i], template=template)
                if parse_data:
                    txt.clean()
                    txt.parseSections()
                pbar.set_description('Parsed #%d' % (i+1))
                pbar.update(1)
                time.sleep(0.01)
                sys.stdout.flush()
                if parse_data:
                    parsed_data.append(txt.tbl)
                if parse_meta:
                    data_source.append(txt.source)
            except SystemExit:
                pass
            except Exception:
                raise
                traceback.print_exc()

    if not parse_meta:
        data_source = None
    if parse_data:
        data_df = pd.concat(parsed_data)

        # data_df reindex
        col_should = ['类目', '项目', '结果', '提示', '范围', '单位', '校验', '来源']
        col_diff = set(col_should).union(set(data_df.columns.tolist())) - \
            set(col_should)
        col_should.extend(list(col_diff))
        data_df = data_df.reindex(columns=col_should)
    else:
        data_df = None

    # completion
    print(str(len(txts)) + u"个txt已解析。请注意核对。")
    root_tk.destroy()

    return {'txt_path': txt_path, 'txt_files': txts, 'txt_src': data_source,
            'txt_df': data_df}


# -------------------main-----------------------------
if __name__ == 'main':
    parsetxt()
