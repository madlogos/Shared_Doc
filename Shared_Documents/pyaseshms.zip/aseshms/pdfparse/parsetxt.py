#! C:/Docs/Continuum/Anaconda3/python.exe
# -*- coding: utf-8 -*-

"""
主题: 解析txt
日期: 2017/12/12
python: 3.6.3_64bit
"""

# -----------------------Import packages----------------------------------
import tkinter as tk
from tqdm import tqdm
import codecs
import pkg_resources
import os
import pandas as pd
import re
import sys
import time
import traceback
import yaml

import aseshms
from aseshms import generic as ag

# ---------------------------Class------------------------------------


class TxtParser:
    def __init__(self, txtfile, template=None, encoding='UTF-8'):
        self.txtfile = txtfile
        self.encoding = encoding
        if template is None:
            self._tpls = yaml.load(pkg_resources.resource_stream(
                    "aseshms", "pdfparse/template.yml"))
        else:
            if re.search(r'.yml', template) or not os.path.isfile(template):
                print(u'模板template必须是有效存在的yml文件。')
                template = ag.get_yaml(multi=False)
            self._tpls = yaml.load(template)
        self.txt = self.meta = self.tbl = self.source = None
        if os.path.isfile(self.txtfile):
            self._readTxt('read')
        if self.txt is not None:
            self.stripEmptyLines()
        self._searchTemplate()
        self._getMeta()

    def clean(self):
        # replace words, split the text and drop sections that are not needed.
        if not isinstance(self.txt, str):
            return
        self._replaceWords()
        self.txt = re.split(r'@=v=@', self.txt)
        self.txt = [sect for sect in self.txt if
                    re.search(r'@=x=@', sect) is None and sect != '']

    def _readTxt(self, mode='read'):
        READ_MODE = ('read', 'readline', 'readlines')
        if mode not in READ_MODE:
            raise ValueError("mode: must be of one value of %r." % READ_MODE)
        with codecs.open(self.txtfile, encoding=self.encoding) as f:
            try:
                if mode == 'read':
                    self.txt = f.read()
                elif mode == 'readline':
                    self.txt = list()
                    for line in open(self.txtfile):
                        line = f.readline()
                        self.txt.append(line)
                elif mode == "readlines":
                    self.txt = f.readlines()
            except Exception:
                traceback.print_exc()
                self.txt = None

    def show(self):
        return self.txt

    def stripEmptyLines(self):
        self.txt = re.sub(r'([\r\n]\n){2,}', r'\r\n', self.txt)

    def __repr__(self):
        return self.txtfile + '\n' + str(self.txt)

    def _searchTemplate(self):
        self.tpl = list()
        for tpl in self._tpls:
            rules = tpl['rule']
            try:
                if all([re.search(rules[i], self.txt) is not None
                        for i in range(len(rules))]):
                    self.tpl.append(tpl)
            except Exception:
                pass
        if len(self.tpl) < 1:
            raise Exception('Did not find any template.' +
                            'Please refine template.yml.')
        elif len(self.tpl) > 1:
            raise Exception('Too many templates found in match of the doc.' +
                            'Please refine template.yml.')
        else:
            self.tpl = self.tpl[0]

    def _extractMeta(self, field):
        # if meta in template has a tuple/list index for extraction
        # then return a list, else a character
        metas = self.tpl['meta']
        try:
            result = re.search(metas[field][0], self.txt).groups()
            if isinstance(metas[field][1], (tuple, list)):
                return [result[x] for x in [metas[field][1]]]
            else:
                return result[metas[field][1]]
        except SystemExit:
            pass
        except Exception:
            return ''

    def _getMeta(self):
        self.meta = dict()
        self.meta['Name'] = self._extractMeta("Name")
        self.meta['Gender'] = self._extractMeta("Gender").replace(u'女士', u'女')   \
            .replace(u'先生', u'男')
        self.meta['Age'] = self._extractMeta("Age")
        self.meta['CertNum'] = self._extractMeta("CertNum")
        yr = self._extractMeta("Yr")
        mo = re.sub(r'^(\d)$', r'0\1', self._extractMeta("Mo"))
        dt = re.sub(r'^(\d)$', r'0\1', self._extractMeta("Dt"))
        self.meta['RegDate'] = "".join([yr, mo, dt])
        self.meta['RecId'] = self._extractMeta("RecId")

    def _replaceWords(self):
        for repl in self.tpl['repl']:
            self.txt = re.sub(repl[0], repl[1], self.txt)

    def parseSections(self):
        # Loop the sections of self.txt and create TxtSectionParser objects
        # call the split_body and make_table methods to parse the txt sections.
        if not isinstance(self.txt, list):
            return
        sections = []
        for section in self.txt:
            section = TxtSectionParser(section, self.tpl)
            section.splitBody()
            section.makeTable()
            sections.append(section.tbl)
        # concat the list to a DF
        self.tbl = pd.concat(sections)
        meta = self.meta
        self.source = '_'.join([meta['Name'], meta['CertNum'], meta['Gender'],
                                meta['Age'], meta['RegDate'], meta['RecId']])
        col_head = self.tbl.columns.tolist()
        col_head = col_head.insert(0, u'来源')
        self.tbl[u'来源'] = pd.Series(self.source, index=self.tbl.index)
        self.tbl.reindex(columns=col_head)


class TxtSectionParser:
    def __init__(self, txt, tpl):
        if isinstance(txt, (tuple, list)):
            self.txt = r"\r\n".join(txt)
        else:
            self.txt = txt
        self.tpl = tpl
        self._searchType()
        self._modulize()
        self._combineAboveBreaks()
        self._combineBelowBreaks()
        self.tbl = None

    def __repr__(self):
        if self.tbl is None:
            return self.txt
        else:
            return self.type + '\n' + str(self.tbl)

    def _searchType(self):
        self.type = list()
        for type, rules in self.tpl['sect'].items():
            try:
                if re.search(rules['header'][0], self.txt) is not None:
                    self.type.append(type)
            except Exception:
                pass
        if len(self.type) < 1:
            raise Exception('Did not find any header pattern.')
        elif len(self.type) > 1:
            raise Exception(
                'Too many header patterns found in match of the text.' +
                'Please refine the template.')
        else:
            self.type = self.type[0]

    def _modulize(self):
        # split self.txt into header and body, with a category/dept tag
        header = self.tpl['sect'][self.type]['header']
        catg = self.tpl['sect'][self.type]['category']
        self.header = re.search(header[0], self.txt).groups()
        self.header = [re.sub(' +', '', s) for s in self.header]
        if isinstance(header[1], (tuple, list)):
            self.header = [self.header[x] for x in header[1]]
        self.catg = re.search(catg[0], self.txt).groups()
        if isinstance(catg[1], (tuple, list)):
            self.catg = [self.catg[x] for x in catg[1]]
        self.body = re.sub(r'^.+?[\r\n]+' + ' *'.join(self.header) +
                           r'[\r\n]+', '', self.txt, re.DOTALL)

    def _combineAboveBreaks(self):
        # must define key words in yaml
        # line breaks are replaced with @=v=@
        combine_above = self.tpl['sect'][self.type]['combine_above']
        if combine_above is None:
            return
        if not isinstance(combine_above, (tuple, list)):
            combine_above = [combine_above, ]
        for begin_word in combine_above:
            while re.search(r'(^|[\r\n]+) {2,}\S+[\r\n]+' + begin_word +
                            r' *\S*[\r\n]+ +', self.body):
                if re.search(u'[总小]结', begin_word):
                    line_sep = '@=v=@'
                else:
                    line_sep = ''
                self.body = re.sub(r'(^|[\r\n]+) {2,}(\S+)[\r\n]+(' +
                                   begin_word + ')( +)(\S+)',
                                   r'\1\3\4\2' + line_sep + r'\5', self.body)

    def _combineBelowBreaks(self):
        # line breaks are replaced with @=v=@
        if len(self.header) == 1:
            return
        while re.search(r'(^|[\r\n]+)\S+( +\S+)*[\r\n]+ +\S+', self.body):
            if re.search(r'(^|[\r\n]+)\S*(小结|总结) +\S+[\r\n]+ +\S+',
                         self.body):
                self.body = re.sub(
                    r'(^|[\r\n]+)(\S*[小总]结 +)(\S+)([\r\n]+) +(\S+)',
                    r'\1\2\3@=v=@\5', self.body)
            elif re.search(r'(^|[\r\n]+)\S+( +\S+)+[\r\n]+ +\S+', self.body):
                self.body = re.sub(
                    r'(^|[\r\n]+)(\S+)( +\S+)+([\r\n]+) +(\S+)',
                    r'\1\2\3\5', self.body)
            else:
                break

    def splitBody(self):
        # split the body into lists
        if len(self.header) == 1:
            return
        self.body = re.split(r'[\r\n]+', self.body)
        self.body = [line for line in self.body if line != '']
        col_blanks = self.tpl['sect'][self.type]['col_blanks']
        try:
            col_blanks = ' {' + col_blanks + '}'
        except Exception:
            col_blanks = r' {5, 25}'
        newbody = list()
        for line in self.body:
            # change @=v=@ back to line breaks
            line = re.sub(r'@=v=@', r'\n', line)
            # if not indep_arrow, merge it
            if not self.tpl['sect'][self.type]['indep_arrow']:
                line = re.sub(r' +([↑↓])', r'\1', line)
            # split the lines to a vector
            line = re.split(col_blanks, line)
            # if over cut, adjust it
            if len(line) > 1:
                if line[1] == '':
                    del line[1]
            # supplement blanks to the vector
            if len(line) < len(self.header):
                line.extend([''] * (len(self.header)-len(line)))
            elif len(line) > len(self.header):
                raise Exception(
                    'The ' + self.type + ' class can only accept ' +
                    str(len(self.header)) + ' columns while you provided ' +
                    str(len(line)) + ':\n' + str(line))
            newbody.append(line)
        self.body = newbody

    def makeTable(self):
        if not isinstance(self.body, list):
            return
        self.tbl = pd.DataFrame.from_records(self.body, columns=self.header)
        col_head = self.tbl.columns.tolist()
        col_head = col_head.insert(0, u'类目')
        self.tbl[u'类目'] = pd.Series(self.catg, index=self.tbl.index)
        self.tbl.reindex(columns=col_head)

    def show(self):
        if self.tbl is None:
            return self.txt
        else:
            return [self.type, self.tbl]

# ---------------------------Main call----------------------------------


def parsetxt(txts=None):
    """
    解析txt为表格
    txts必须在同一个文件夹内
    返回dict {'txt_path':文件夹路径txt_path, 'txt_files': 各txt文件路径
        , 'txt_src': 各txt的来源信息(用于改名), 'txt_df': DataFrame txts数据}
    txts: txts路径，如为None，则启动GUI向导选择
    """
    root_tk = tk.Tk()
    root_tk.withdraw()

    gui = txts is None

    if gui:
        # 找到txts，确保文件夹内有txt
        txt_path, txts = ag.get_txts(initialdir=aseshms.PKGINFO.cwdir).values()
    else:
        if not isinstance(txts, (list, tuple)):
            txts = [txts, ]
        txts = [txt for txt in txts if os.path.isfile(txt)]
        txt_path = ag.get_files_dir(txts)
        if txt_path == '':
            raise ValueError(u"txts不属于同一个文件夹。\n请注意核对。")
            return
        if len(txts) == 0:
            raise ValueError(u"路径参数txts无效，未找到任何可用的txt文件。\n请注意核对。")
            return

    # parse the txts
    parsed_data = []
    data_source = []
    values = range(len(txts))
    try:
        with tqdm(total=len(values), file=sys.stdout) as pbar:
            for i in values:
                txt = TxtParser(txts[i])
                txt.clean()
                txt.parseSections()
                pbar.set_description('Processed %d' % (i+1))
                pbar.update(1)
                time.sleep(0.01)
                sys.stdout.flush()
                parsed_data.append(txt.tbl)
                data_source.append(txt.source)
        data_df = pd.concat(parsed_data)

    except SystemExit:
        pass
    except Exception:
        traceback.print_exc()
        return

    # complete
    print(str(len(txts)) + u"个txt已解析。请注意核对。")
    root_tk.destroy()

    return {'txt_path': txt_path, 'txt_files': txts, 'txt_src': data_source,
            'txt_df': data_df}


if __name__ == 'main':
    parsetxt()
