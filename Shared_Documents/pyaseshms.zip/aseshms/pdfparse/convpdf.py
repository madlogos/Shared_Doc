# -*- coding: utf-8 -*-

"""
主题: 将文件夹内的pdf转为txt，产生解析excel文档模板
日期: 2017/12/06
python: 3.6.3_64bit
"""

__all__ = ['set_conversion_mode', 'PdfParser', 'convert_pdfs', 'pdf2txt',
           'pdf2html', 'pdf2ps', 'pdf2ppm', 'pdf2png']

# -----------------------Import packages----------------------------------
import tkinter as tk
from subprocess import Popen, PIPE
from pandas import DataFrame as DF
from tqdm import tqdm
import os
import re
import shutil
import sys
import time
import traceback

import aseshms
from aseshms import generic as ag
from aseshms import util as au


# ---------------------------Tool Functions------------------------------------
def set_conversion_mode(
    modes=[(u"带格式 (-layout)", "-layout"),
           (u"不分页 (-nopgbrk)", "-nopgbrk"),
           (u"无格式 ( )", " "), (u"成表格 (-table)", "-table"),
           (u"原格式 (-raw)", "-raw"),
           (u"精简化 (-simple)", "-simple")]):
    """
    GUI选择xpdf转换的模式

    Args:
        modes (list): 可用的转换模式, 可自行添加:
           [(u"带格式 (-layout)", "-layout"),
            (u"不分页 (-nopgbrk)", "-nopgbrk"),
            (u"无格式 ( )", " "),
            (u"成表格 (-table)", "-table"),
            (u"原格式 (-raw)", "-raw"),
            (u"精简化 (-simple)", "-simple")]

    Returns:
        用户在tk界面点选的模式值
    """
    win_master = tk.Tk()
    win_master.title(u"选定xpdf转换pdf的模式")
    conv_mode = au.GuiRadioChecker(win_master, init_val=u"-table",
                                   val_list=modes)
    win_master.mainloop()
    win_master.destroy()
    return conv_mode.show()


# ------------------------Aggregated Work function-----------------------------
class PdfParser(object):
    """
    Pdf parser wrapper. It calls xpdf to convert pdfs.

    Attributes:
        file (str): Path of the pdf file to parse.
        mode (str): Convertion mode of pdftotext: [u"-layout", u"-nopgbrk",
            " ", u"-table", u"-raw", u"-simple"]. Default '-table'.
        encoding (str): Default 'GBK', to be compatible of Chinese.
        meta (dict): Meta info of the pdf file.
    """
    def __init__(self, file, mode=u"-table", encoding=u'GBK'):
        """__init__ mothod of PdfParser

        Args:
            file (str): Path of the pdf file to parse.
            mode (str): Convertion mode of pdftotext: [u"-layout", u"-nopgbrk",
                " ", u"-table", u"-raw", u"-simple"]. Default '-table'.
            encoding (str): Default 'GBK', to be compatible of Chinese.
        """
        CONVERSION_MODE = [u"-layout", u"-nopgbrk", " ", u"-table", u"-raw",
                           u"-simple"]
        if mode not in CONVERSION_MODE:
            raise ValueError("mode: must be of values in %r." %
                             CONVERSION_MODE)
        if os.path.isfile(file):
            self.file = file
        else:
            self.file = None
        self.mode = mode
        self.encoding = encoding
        self.getMeta()

    def getMeta(self):
        """Call pdfinfo.exe to extract meta info of the pdf, and collect it
        from the stdout."""
        if self.file is None:
            self.meta = None
        else:
            try:
                with Popen(''.join([aseshms.PKGINFO['pdfinfo'], ' -enc ',
                                    self.encoding, ' -meta "', self.file,
                                    '"']),
                           stdout=PIPE, stderr=PIPE) as subproc:
                    out, err = subproc.communicate()
                subproc.terminate()
                lines = out.decode(self.encoding.lower()).splitlines()
                lines = [re.split(': {2,}', f) for f in lines]
                lines.append(['Filename',
                              re.sub(r'^.+?([^\\/]+)\.[Pp][Dd][Ff]$', r'\1',
                                     self.file)])
                lines = {lines[j][0]: lines[j][1] for j in
                         range(0, len(lines))}
                self.meta = lines
            except Exception:
                traceback.print_exc()
                self.meta = None

    def convert(self, tool):
        """Call pdf coversion tool to convert the pdf. Quick calls:
            convertToTxt:  tool = 'pdftotext'
            convertToHtml: tool = 'pdftohtml'
            convertToPs:   tool = 'pdftops'
            convertToPng:  tool = 'pdftopng'
            convertToPpm:  tool = 'pdftoppm'
        """
        VALID_TOOLS = ['pdftotext', 'pdftohtml', 'pdftops', 'pdftopng',
                       'pdftoppm']
        if tool not in VALID_TOOLS:
            raise ValueError("tool must be one of %r" % VALID_TOOLS)

        try:
            if tool in ['pdftotext', ]:
                os.system(''.join([aseshms.PKGINFO[tool], ' ', self.mode, ' "',
                                   self.file, '"']))
            elif tool in ['pdftohtml']:
                htmlfolder = re.split(r'[\\/]',
                                      os.path.splitext(self.file)[0])[-1]
                if os.path.exists(os.path.dirname(self.file) + '/' +
                                  htmlfolder):
                    shutil.rmtree(os.path.dirname(self.file) + '/' +
                                  htmlfolder)
                os.system(''.join(
                    [aseshms.PKGINFO[tool], ' "', self.file, '" "',
                     os.path.dirname(self.file), '/', htmlfolder, '"']))
            else:
                os.system(''.join([aseshms.PKGINFO[tool], ' "',
                                   self.file, '"']))
        except Exception:
            raise Exception('Conversion of %r failed using %s' %
                            (str(self.file), tool))
            traceback.print_exc()

    def convertToTxt(self):
        """Quick call of convert()"""
        self.convert(tool='pdftotext')

    def convertToHtml(self):
        """Quick call of convert()"""
        self.convert(tool='pdftohtml')

    def convertToPs(self):
        """Quick call of convert()"""
        self.convert(tool='pdftops')

    def convertToPng(self):
        """Quick call of convert()"""
        self.convert(tool='pdftopng')

    def convertToPpm(self):
        """Quick call of convert()"""
        self.convert(tool='pdftoppm')


# ---------------------------Main call----------------------------------
def convert_pdfs(pdfs=None, mode="-table", towhat="txt", verbose=True):
    """
    将pdf转换为其他文件，pdfs必须在同一个文件夹内。快捷函数包括: pdf2txt, pdf2html,
    pdf2ps, pdf2ppm, pdf2png

    Args:
        pdfs (str): pdfs路径，如为None，则启动GUI向导选择
        mode (str, 可选): ["-layout", "-nopgbrk", " ", "-table", "-raw",
            "-simple"]
        towhat (str, 可选): ['txt', 'html', 'png', 'ppm', 'ps'], 默认'txt'
        verbose (bool, 可选): 是否返回详细，默认为True

    Returns:
        如verbose为True，返回dict {'pdf_path':文件夹路径pdf_path,
            'pdf_files': 各pdf文件路径, 'pdf_info': DataFrame pdfs元数据}
    """
    root_tk = tk.Tk()
    root_tk.withdraw()

    # Argument validation
    gui = pdfs is None or mode is None
    TO_FORM = {'txt': 'pdftotext', 'html': 'pdftohtml', 'png': 'pdftopng',
               'ppm': 'pdftoppm', 'ps': 'pdftops'}
    towhat = towhat.lower()
    if towhat not in TO_FORM.keys():
        raise ValueError('towhat: must be of values %r.' % TO_FORM.keys())
    if not isinstance(pdfs, (list, tuple)):
        pdfs = [pdfs, ]
    if isinstance(mode, (list, tuple)):
        mode = mode[0]

    # pdf and conv_mode selection
    if gui:
        # 找到pdfs，确保文件夹内有pdf
        pdf_path, pdfs = ag.get_pdfs(
            initialdir=aseshms.PKGINFO['cwdir']).values()
        if mode is None:
            mode = set_conversion_mode()
    else:
        pdfs = [pdf for pdf in pdfs if os.path.isfile(pdf)]
        pdfs_show = str(pdfs)[:200]
        if len(pdfs) < 1:
            raise ValueError(u'参数pdfs %s 路径均无效。' % pdfs_show)
        pdf_path = ag.get_files_dir(pdfs)
        if pdf_path == '':
            raise ValueError(u"pdfs %s 不属于同一个文件夹。\n请注意核对:" %
                             pdfs_show)
            return
        if len(pdfs) == 0:
            raise ValueError((u"路径参数pdfs %s 无效，未找到任何可用的pdf文件。"
                              u"\n请注意核对。") % pdfs_show)
            return

    # 循环转换，并输出DataFrame pdfinfo
    global info_out
    info_out = list()
    values = range(len(pdfs))
    try:
        with tqdm(total=len(values), file=sys.stdout) as pbar:
            for i in values:
                pdf = PdfParser(pdfs[i], mode=mode)
                pdf.convert(tool=TO_FORM[towhat])
                pbar.set_description('Converted #%d' % (i+1))
                pbar.update(1)
                time.sleep(0.01)
                sys.stdout.flush()
                info_out.append(pdf.meta)
    except SystemExit:
        pass
    except Exception:
        traceback.print_exc()

    # complete
    print(str(len(pdfs)) + u"个pdf已转换。请注意核对。")
    root_tk.destroy()

    if verbose:
        return {'pdf_path': pdf_path, 'pdf_files': pdfs,
                'pdf_info': DF.from_dict(info_out)}


def pdf2txt(pdfs=None, mode="-table"):
    return convert_pdfs(pdfs, mode, towhat="txt")


def pdf2html(pdfs=None, mode="-table"):
    return convert_pdfs(pdfs, mode, towhat="html")


def pdf2ps(pdfs=None, mode="-table"):
    return convert_pdfs(pdfs, mode, towhat="ps")


def pdf2ppm(pdfs=None, mode="-table"):
    return convert_pdfs(pdfs, mode, towhat="ppm")


def pdf2png(pdfs=None, mode="-table"):
    return convert_pdfs(pdfs, mode, towhat="png")


# ----------------------main-------------------------
if __name__ == 'main':
    pdf2txt()
