# -*- coding: utf-8 -*-

from setuptools import setup, find_packages


setup(
    name='aseshms',
    version='0.1.0',
    keywords='ases hms data toolkit',
    description='a toolkit library for ASES CoE team',
    license='MIT License',
    url='',
    author='Yiying WANG',
    author_email='wangy@aetna.com',
    packages=find_packages(),
    include_package_data=True,
    platforms='any',
    install_requires=["tkinter", "pandas", "xlsxwriter", "tqdm",
                      "pkg_resources", "openpyxl", "numpy"],
)
