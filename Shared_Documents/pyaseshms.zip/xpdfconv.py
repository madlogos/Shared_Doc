#! C:/ProgramData/Continuum/Anaconda3/python.exe
# -*- coding: utf-8 -*-

import os
# import pdb
import re
import time
# import cProfile
import pandas as pd
# sys.stdout = io.TextIOWrapper(sys.stdout.detach(), encoding='utf-8')
from aseshms.pdfparse import convpdf
from aseshms.pdfparse import parsetxt

# -----------------config the file------------------
file = 'H:/data/python scripts/aseshms/testcase/pdf/sample03'

if not os.path.exists('%s.txt' % file):
    convpdf.convert_pdfs('%s.pdf' % file, verbose=False)
parser = parsetxt.TxtParser('%s.txt' % file)
txtlen = len(parser.txt)
parser.clean()
sectlen = [len(v) for v in parser.txt]
# pdb.set_trace()
parser.parseSections()

open('H:/data/python scripts/xpdfconv.log', 'w').close()  # clear contents
with open('H:/data/python scripts/xpdfconv.log', 'w', encoding="GBK") as f:
    f.write('%s: %s\n' % (file, txtlen))
    f.write('%s\n\n' % time.strftime('%x %a %X %z',
                                     time.localtime(time.time())))
    f.write('====================Meta=======================\n')
    f.write('Template: %s\n' % str(parser.tpl['name']))
    f.write('%s\n' % str(parser.meta))
    f.write('%r\n\n' % str(sectlen))
    f.write('==================Sections=====================\n')
    f.write('table rows: %s\n' % (len(parser.tbl.index)))
    for i in range(len(parser.sections)):
        f.write('\n------------------Section #%d-------------------\n' % i)
        for k, v in parser.sections[i].items():
            try:
                if isinstance(v, list) and len(v) > 0:
                    if isinstance(v[0], list):
                        rslt = [str(lst) for lst in v]
                        f.write('%r:\n\t%s\n' % (k, '%s' %
                                '\n\t'.join(rslt)))
                    else:
                        f.write('%r:\t%r\n' % (k, v))
                else:
                    f.write('%r:\t%s\n' % (k, re.sub(r'\n', r'\n\t', v)))
            except Exception:
                print('error in %r:%r.' % (k, v))
                raise

col_should = ['类目', '项目', '结果', '提示', '范围', '单位', '校验', '来源']
col_diff = set(col_should).union(set(parser.tbl.columns.tolist())) - \
    set(col_should)
col_should.extend(list(col_diff))
parser.tbl = parser.tbl.reindex(columns=col_should)

xlwriter = pd.ExcelWriter("H:/data/python scripts/xpdfconv.xlsx",
                          engine='xlsxwriter')
parser.tbl.to_excel(xlwriter, 'Sheet 1',
                    index_label=["Idx", parser.tbl.columns.tolist()])
xlwriter.save()
