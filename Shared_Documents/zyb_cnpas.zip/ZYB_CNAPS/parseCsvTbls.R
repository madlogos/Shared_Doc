setwd("H:/Data/iMacro/Downloads/CNAPS")
Sys.setlocale("LC_CTYPE", "Chs")
library(readr)
library(parallel)
library(compiler)
library(magrittr)
files <- list.files(".")
files <- files[!grepl("zip$|bat$", files)]
if (!all(grepl("csv$", files))){
  file.rename(files[!grepl("csv$", files)], 
            paste0(files[!grepl("csv$", files)], ".csv"))
}
files <- list.files(getwd(), pattern="\\.csv$", full.names=FALSE)
stopifnot(all(grepl("csv$", files)))
message("A total of ", length(files), " files read.")
# ---------------UDFs-----------------
getCbId <- function(grpId=NA){
  # Copy XML nodes from ZYB page by F12
  a <- readClipboard(format=13)
  a <- unlist(strsplit(a, "\""))
    a <- a[seq(2, length(a), 2)]
    if (is.na(grpId)){
        toJSON(as.numeric(a))
    }else{
        a=matrix(as.numeric(c(rep.int(grpId, length(a)), a)), ncol=2)
        toJSON(a)
    }
}
parseCsvTbl <- cmpfun(function(csvfile, 
                               header=c("CNAPS", "Bank", "Tel", "Addr")){
    # for parallel use, dup the global settings
    Sys.setlocale("LC_CTYPE", "Chs")
    stopifnot(length(header) == 4)
    stopifnot(file.exists(csvfile))
    dat <- readr::read_csv(csvfile, col_types="nccc")
    names(dat) <- header
    dat$bank <- sub("^([^_]*?)_([^_]*?)_([^_]*?)_.+$", "\\1", csvfile)
    dat$prov <- sub("^([^_]*?)_([^_]*?)_([^_]*?)_.+$", "\\2", csvfile)
    dat$city <- sub("^([^_]*?)_([^_]*?)_([^_]*?)_.+$", "\\3", csvfile)
    return(dat)
})
if (length(files) > 1000){
	cl <- makeCluster(detectCores())
	df <- do.call("rbind", parLapply(cl, files, parseCsvTbl))
	stopCluster(cl)
}else{
	df <- do.call("rbind", lapply(files, parseCsvTbl))
}
write_csv(df, paste0("cnaps_", format(Sys.time(), "%Y%m%d%H%M%S"), ".csv"))
message("output cnaps csv is generated.")